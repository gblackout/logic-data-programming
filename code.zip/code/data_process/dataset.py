from os.path import join as joinpath
import re
from common.utils import iterline
from common.constants import const_dict, TYPE_SET
from common.predicate import pred_register, Predicate
from copy import deepcopy
from common import constants
import os
import math
import torch
from tqdm import tqdm
import itertools
from common.cmd_args import cmd_args
from random import shuffle
import random
from typing import Set


class Dataset:

    def __init__(self, dataset_path):

        pred_path = joinpath(dataset_path, 'pred.txt')
        fact_path = joinpath(dataset_path, 'fact.txt')

        self.fact_dict, self.fact_dict_sort, \
        self.const_dict_sort, self.pred2sgraph_dict = preprocess(pred_path, fact_path)

        self.unp_ls = [ind for ind in range(pred_register.num_pred) if pred_register.is_unp(ind)]
        self.bip_ls = [ind for ind in range(pred_register.num_pred) if not pred_register.is_unp(ind)]
        # move ident to last
        self.bip_ls.remove(pred_register.pred2ind[constants.IDENT_PHI])
        self.bip_ls.append(pred_register.pred2ind[constants.IDENT_PHI])

    def sample_pred(self, recursion=True):

        for ls_ind, p_ls in enumerate([self.unp_ls, self.bip_ls]):
            for ind, p_ind in enumerate(p_ls):

                # skip ident as p star
                if pred_register.get_class(p_ind).name == constants.IDENT_PHI:
                    continue

                unp_ls, bip_ls = deepcopy(self.unp_ls), deepcopy(self.bip_ls)

                if recursion:
                    [unp_ls, bip_ls][ls_ind].pop(ind)

                yield p_ind, unp_ls, bip_ls

    def sample_fact(self, p_star):
        for val, consts in self.fact_dict_sort[pred_register.get_class(p_star).name]:
            yield val, consts

    def num_consts(self, type_name=None):

        if type_name is None:
            return sum([len(const_list) for const_list in self.const_dict_sort.items()])
        else:
            return len(self.const_dict_sort[type_name])


class SubGraphDataset:

    def __init__(self, dataset_path):

        pred_path = joinpath(dataset_path, 'pred.txt')
        train_path = joinpath(dataset_path, 'train.txt') # used in tensorlog data
        fact_path = joinpath(dataset_path, 'fact.txt' if cmd_args.kb else 'fact_domains')
        valid_path = joinpath(dataset_path, 'valid.txt' if cmd_args.kb else 'valid_domains')
        test_path = joinpath(dataset_path, 'test.txt' if cmd_args.kb else 'test_domains')
        ent_path = joinpath(dataset_path, 'ent.txt')

        fact_path_ls = [fact_path] + ([train_path] if os.path.isfile(train_path) else [])
        valid_path_ls = [valid_path]
        test_path_ls = [test_path]
        ent_path_ls = [ent_path] if os.path.isfile(ent_path) else None

        self.fact_pred2sgraph_dict = preprocess_withSubGraph(pred_path, fact_path_ls, ent_path_ls)
        self.valid_pred2sgraph_dict = preprocess_withSubGraph(pred_path, valid_path_ls, ent_path_ls)
        self.test_pred2sgraph_dict = preprocess_withSubGraph(pred_path, test_path_ls, ent_path_ls)

        self.sgraph_dict = {}
        for p2sgraph_dict in [self.fact_pred2sgraph_dict, self.valid_pred2sgraph_dict, self.test_pred2sgraph_dict]:
            for sgraph_ls in p2sgraph_dict.values():
                for sgraph in sgraph_ls:
                    self.sgraph_dict[sgraph.name] = sgraph

    def sample(self, pred2sgraph_dict, batch_size, allow_recursion, rotate, keep_array, tgt_pred_ls, bg_sgraph,
               allowed_p_set: Set[str] = None):

        iter_ls = [self.batch_iter(pred2sgraph_dict, batch_size, pn, allow_recursion,
                                   keep_array, bg_sgraph, allowed_p_set) for pn in tgt_pred_ls]

        num_batch_ls = [self.get_numBatches(pred2sgraph_dict, pn, batch_size) for pn in tgt_pred_ls]
        num_batches = sum(num_batch_ls)

        # tmp = sorted(enumerate(num_batch_ls), key=lambda x: x[1], reverse=True)
        # tmp = [e for e in tmp if e[1] > 50]
        # iter_ls = [iter_ls[e[0]] for e in tmp]
        def epoch_iterator():
            if rotate:
                for rotate_ls in itertools.zip_longest(*iter_ls):  # [(p1,q1), (p2,q2), (p3,None), ...]
                    for batch in rotate_ls:
                        if batch is not None:
                            yield batch
            else:
                for it in iter_ls:
                    for batch in it:
                        yield batch

        # TODO debug
        # sample balance among all tgt preds, append samples to match the longest p_star
        # max_batches = max([math.ceil(self.get_numSamples(pred2sgraph_dict, pn) / batch_size) for pn in tgt_pred_ls])
        # max_batches = max([self.get_numBatches(pred2sgraph_dict, pn, batch_size) for pn in tgt_pred_ls])
        # num_batches = max_batches * len(tgt_pred_ls)
        #
        # def epoch_iterator():
        #     if rotate:
        #         for _ in range(max_batches):
        #             b_ls = [next(e, None) for e in iter_ls]
        #             for iter_ind, batch in enumerate(b_ls):
        #                 if batch is None:
        #                     iter_ls[iter_ind] = self.batch_iter(pred2sgraph_dict, batch_size, tgt_pred_ls[iter_ind],
        #                                                         allow_recursion, keep_array, bg_sgraph)
        #                     batch = next(iter_ls[iter_ind])
        #                 yield batch
        #
        #     else:
        #         for it in iter_ls:
        #             for batch in it:
        #                 yield batch

        return num_batches, epoch_iterator()

    def get_numBatches(self, pred2sgraph_dict, pred_name, bsize, allowed_p_set: Set[str] = None):
        cnt = 0
        allowed = lambda x: (x in allowed_p_set) if allowed_p_set else True
        for sgraph in pred2sgraph_dict[pred_name]:

            unp_ls, bip_ls = [pn for pn in sgraph.unp_ls if allowed(pn)], \
                             [pn for pn in sgraph.bip_ls if allowed(pn)]
            if (len(unp_ls) == 0) or (len(bip_ls) < 1):
                continue

            cnt += math.ceil(len(sgraph.fact_dict[pred_name]) / bsize)
        return cnt

    def get_numSamples(self, pred2sgraph_dict, pred_name):
        cnt = 0
        for sgraph in pred2sgraph_dict[pred_name]:
            cnt += len(sgraph.fact_dict[pred_name])
        return cnt

    def batch_iter(self, pred2sgraph_dict, batch_size, p_star, allow_recursion, keep_array, bg_sgraph, allowed_p_set):
        """
            iterator that enumerates batches for p_star in all sgraphs. No cross-sgraph batches

        :param batch_size:
        :param p_star:
        :param allow_recursion:
        :param keep_array:
        :return:
             unp_arr_ls: [num_unp, (b, num_ent, 1)], same data expanded to bsize samples
             bip_arr_ls: [num_bip+1, (1, num_ent, num_ent)], +1 for ident_phi
             arg_input: (bsize, num_args, num_ents)
             input_y: (bsize)
        """

        assert p_star != constants.IDENT_PHI

        is_unp = pred_register.is_unp(p_star)
        # if allowed set provided then check, otherwise always true
        allowed = lambda x: (x in allowed_p_set) if allowed_p_set else True

        for sgraph in pred2sgraph_dict[p_star]:
            num_unp, num_bip, num_ents = len(sgraph.unp_ls), len(sgraph.bip_ls), len(sgraph.const2ind_dict)
            tgt_sgraph = sgraph if bg_sgraph is None else bg_sgraph
            sgraph_unp_arr_ls, sgraph_bip_arr_ls = tgt_sgraph.toArray(keep_array=keep_array)

            unp_ls, bip_ls = [pn for pn in tgt_sgraph.unp_ls if allowed(pn)], \
                             [pn for pn in tgt_sgraph.bip_ls if allowed(pn)]
            unp_arr_ls, bip_arr_ls = [unp_arr for unp_arr, pn in zip(sgraph_unp_arr_ls, tgt_sgraph.unp_ls) if allowed(pn)], \
                                     [bip_arr for bip_arr, pn in zip(sgraph_bip_arr_ls, tgt_sgraph.bip_ls) if allowed(pn)]

            if not allow_recursion:
                tgt_ls, tgt_arr_ls = (unp_ls, unp_arr_ls) if is_unp else (bip_ls, bip_arr_ls)
                try:
                    ind = tgt_ls.index(p_star)
                    tgt_ls.pop(ind)
                    tgt_arr_ls.pop(ind)
                except:
                    pass

            # filter the case where no unp and bip are allowed (+1 for Ident in bip_ls)
            if (len(unp_ls) == 0) or (len(bip_ls) < 1):
                continue

            train_pair_ls = sgraph.fact_dict[p_star]
            sgraph_numSamples = len(train_pair_ls)

            cnt = 0  # bsize can be smaller than batch_size if sgraph is small
            while cnt * batch_size < sgraph_numSamples:
                arg_input_ls = []
                input_y = []
                batch_pair_ls = train_pair_ls[cnt * batch_size:(cnt + 1) * batch_size]
                for ind, pair in enumerate(batch_pair_ls):
                    arg_input = torch.zeros(1 if is_unp else 2, num_ents)
                    val, consts = pair
                    for c_ind, const in enumerate(consts):
                        arg_input[c_ind, sgraph.const2ind_dict[const]] = 1
                    input_y.append(val)
                    arg_input_ls.append(arg_input)

                # sample neg on-the-fly, use mix_choice to choose correct one with 1/3 prob, and others with 2/3
                if cmd_args.sample_neg:
                    neg_y, neg_arg_input_ls = [], []
                    for ind in range(len(batch_pair_ls)):
                        arg_input = torch.zeros(1 if is_unp else 2, num_ents)
                        for c_ind in ([0] + ([] if is_unp else [1])):
                            arg_input[c_ind, random.randint(0, num_ents - 1)] = 1
                        neg_y.append(0)
                        neg_arg_input_ls.append(arg_input)

                    mix_choice = [random.randint(0, 2) for _ in range(len(batch_pair_ls))]
                    input_y = [[input_y, neg_y, neg_y][c][ind] for ind, c in enumerate(mix_choice)]
                    arg_input_ls = [[arg_input_ls, neg_arg_input_ls, neg_arg_input_ls][c][ind] for ind, c in
                                    enumerate(mix_choice)]

                cnt += 1
                input_y = torch.tensor(input_y, dtype=torch.float32, device=cmd_args.device)
                arg_input = torch.stack(arg_input_ls, dim=0).to(cmd_args.device)

                yield [[unp_arr_ls, bip_arr_ls], arg_input], input_y, unp_ls, bip_ls, p_star, sgraph.name


class SubGraph:

    def __init__(self, unp_ls, bip_ls, const2ind_dict, ind2const_dict, fact_dict):

        self.unp_ls = unp_ls
        # manually put Ident predicate into the list, though it's in pred_register
        self.bip_ls = bip_ls + [constants.IDENT_PHI]
        self.const2ind_dict = const2ind_dict
        self.ind2const_dict = ind2const_dict
        self.fact_dict = fact_dict
        self.name = None
        self.has_neg_sample = False

        self.unp_arr_ls, self.bip_arr_ls = None, None

    def toArray(self, update=False, keep_array=False):
        """

        :param update:
            set to true for re-computing the array
        :param keep_array:
            keep the generated array, useful if in single sgraph env, i.e. non-GQA tasks
        :return:
            unp_array of (num_unp, num_const, 1)
            bip_array of (num_bip, num_const, num_const)
        """

        if (self.unp_arr_ls is not None) and (self.bip_arr_ls is not None) and (not update):
            return self.unp_arr_ls, self.bip_arr_ls

        num_unp, num_bip, num_const = len(self.unp_ls), len(self.bip_ls), len(self.const2ind_dict)

        unp_arr_ls = [torch.zeros(num_const, 1, device=cmd_args.device) for _ in range(num_unp)]

        for ind, unp in enumerate(self.unp_ls):
            for val, consts in self.fact_dict[unp]:
                entry_inds = tuple([self.const2ind_dict[const] for const in consts])
                unp_arr_ls[ind][entry_inds] = val

        if cmd_args.sparse_mat:
            bip_arr_ls = []

            for _, bip in enumerate(self.bip_ls[:-1]):
                ind_ls, val_ls = [], []
                for val, consts in self.fact_dict[bip]:
                    ind_ls.append([self.const2ind_dict[const] for const in consts])
                    val_ls.append(val)
                ind_arr = torch.LongTensor(ind_ls).transpose(0, 1)
                val_arr = torch.FloatTensor(val_ls)
                bip_arr_ls.append(
                    torch.sparse_coo_tensor(ind_arr, val_arr, [num_const, num_const], device=cmd_args.device))

            # ident a placeholder
            bip_arr_ls.append(torch.sparse_coo_tensor([[], []], [], [num_const, num_const], device=cmd_args.device))

        else:
            bip_arr_ls = [torch.zeros(num_const, num_const, device=cmd_args.device) for _ in range(num_bip - 1)] + \
                         [torch.eye(num_const, device=cmd_args.device)]

            for ind, bip in enumerate(self.bip_ls[:-1]):
                for val, consts in self.fact_dict[bip]:
                    entry_inds = tuple([self.const2ind_dict[const] for const in consts])
                    bip_arr_ls[ind][entry_inds] = val

        if keep_array:
            self.unp_arr_ls = unp_arr_ls
            self.bip_arr_ls = bip_arr_ls

        return unp_arr_ls, bip_arr_ls


def gen_neg_samples(sgraph, unp_ls, bip_ls, sample_ratio=1, global_unp_arr=None, global_bip_arr=None):
    """
        offline sample neg, sample (num_pos_samples * sample_ratio) entries with zero value in the matrix and add them
        into the fact_dict

    :param sgraph:
    :param unp_ls:
    :param bip_ls:
    :param sample_ratio:
    :param global_unp_arr:
        used for single sgraph case
    :param global_bip_arr:
        used for single sgraph case
    :return:

    """

    sgraph_unp2ind_dict = dict([(pn, ind) for ind, pn in enumerate(sgraph.unp_ls)])
    sgraph_bip2ind_dict = dict([(pn, ind) for ind, pn in enumerate(sgraph.bip_ls)])

    unp_arr_ls, bip_arr_ls = sgraph.toArray() if global_unp_arr is None else (global_unp_arr, global_bip_arr)
    num_const = bip_arr_ls[0].size(0)

    for pn in unp_ls:
        if pn not in sgraph_unp2ind_dict:
            continue  # '%s not in sgraph %s' % (pn, sgraph.name)

        if len(sgraph.fact_dict[pn]) == 0:
            continue

        unp_ind = sgraph_unp2ind_dict[pn]
        unp_neg_indices = (1 - unp_arr_ls[unp_ind]).nonzero()[:, 0]
        num_pos_samples = num_const - unp_neg_indices.size(0)

        perm_indices = torch.randperm(unp_neg_indices.size(0))[:num_pos_samples * sample_ratio]  # permute neg samples
        unp_neg_indices = unp_neg_indices[perm_indices]

        for neg_ind in unp_neg_indices:
            consts = tuple([sgraph.ind2const_dict[int(neg_ind)]])
            sgraph.fact_dict[pn].append((0, consts))

        shuffle(sgraph.fact_dict[pn])

    for pn in bip_ls:
        if pn not in sgraph_bip2ind_dict:
            continue  # '%s not in sgraph %s' % (pn, sgraph.name)

        if len(sgraph.fact_dict[pn]) == 0:
            continue

        bip_ind = sgraph_bip2ind_dict[pn]
        bip_neg_indices = (1 - bip_arr_ls[bip_ind]).nonzero()
        num_pos_samples = num_const ** 2 - bip_neg_indices.size(0)

        if num_pos_samples == 0:
            continue

        # multiply by 2 for 2 slots
        perm_indices = torch.randperm(bip_neg_indices.size(0))[
                       :num_pos_samples * sample_ratio * 2]  # permute neg samples
        bip_neg_indices = bip_neg_indices[perm_indices]

        for neg_ind in bip_neg_indices:
            consts = tuple([sgraph.ind2const_dict[int(e)] for e in neg_ind])
            sgraph.fact_dict[pn].append((0, consts))

        shuffle(sgraph.fact_dict[pn])

    sgraph.has_neg_sample = True


def preprocess_withSubGraph(pred_path, fact_path_ls, ent_path_ls=None):
    pred_reg = re.compile(r'([\w-]+)\(([^)]+)\)')

    for line in iterline(pred_path):
        m = pred_reg.match(line)

        # TensorLog data
        if m is None:
            pred_name = line
            pred_name = pred_name.replace('.', 'DoT')  # deal with fb15k
            var_types = ['type', 'type']
        else:
            pred_name = m.group(1)
            var_types = m.group(2).split(',')

        if pred_name in pred_register.pred_dict:
            continue

        pred_register.add(Predicate(pred_name, var_types))
        TYPE_SET.update(var_types)

    if constants.IDENT_PHI not in pred_register.pred_dict:
        pred_register.add(Predicate(constants.IDENT_PHI, ['type', 'type']))

    if ent_path_ls is not None:
        global_const2ind, global_ind2const = {}, {}
        for fp in ent_path_ls:
            for line in iterline(fp):
                if line not in global_const2ind:
                    global_ind2const[len(global_const2ind)] = line
                    global_const2ind[line] = len(global_const2ind)
    else:
        global_const2ind, global_ind2const = None, None

    def parse_fact(fp_ls, const2ind_dict, ind2const_dict, verbose=False, keep_empty=False):
        unp_set, bip_set = set(), set()
        const2ind_dict = {} if const2ind_dict is None else const2ind_dict
        ind2const_dict = {} if ind2const_dict is None else ind2const_dict
        fact_dict = dict([(pn, []) for pn in pred_register.pred_dict.keys()]) if keep_empty else {}

        if verbose:
            v = lambda x: tqdm(x)
        else:
            v = lambda x: x

        for fp in fp_ls:
            for line in v(iterline(fp)):
                parts = line.split('\t')

                # TensorLog case
                if len(parts) == 3:
                    val = 1
                    e1, pred_name, e2 = parts
                    pred_name = pred_name.replace('.', 'DoT')  # deal with fb15k
                    consts = [e1, e2]
                else:
                    val = int(parts[0])
                    m = pred_reg.match(parts[1])
                    assert m is not None

                    pred_name = m.group(1)
                    consts = m.group(2).split(',')

                if pred_name not in pred_register.pred_dict:
                    continue

                for const in consts:
                    if const not in const2ind_dict:
                        ind2const_dict[len(const2ind_dict)] = const
                        const2ind_dict[const] = len(const2ind_dict)

                fact = (val, tuple(consts))
                if pred_name in fact_dict:
                    fact_dict[pred_name].append(fact)
                else:
                    fact_dict[pred_name] = [fact]

                if pred_register.is_unp(pred_name):
                    unp_set.add(pred_name)
                else:
                    bip_set.add(pred_name)

        if keep_empty:
            pn_ls = list(pred_register.pred_dict.keys())
            unp_ls = [pn for pn in pn_ls if pred_register.is_unp(pn)]
            bip_ls = [pn for pn in pn_ls if not pred_register.is_unp(pn)]
        else:
            unp_ls = list(sorted(unp_set))
            bip_ls = list(sorted(bip_set))

        return SubGraph(unp_ls, bip_ls, const2ind_dict, ind2const_dict, fact_dict)

    pred2sgraph_dict = dict((pred_name, []) for pred_name in pred_register.pred_dict)
    # a single file containing all facts, e.g. FB15K
    if os.path.isfile(fact_path_ls[0]):
        tqdm.write('Processing Single SubGraph..')
        d = parse_fact(fact_path_ls, global_const2ind, global_ind2const, verbose=True)
        d.name = 'default'
        for k in pred2sgraph_dict.keys():
            pred2sgraph_dict[k].append(d)

    # a folder containing fact files named with unique ids, e.g. GQA images
    elif os.path.isdir(fact_path_ls[0]):
        assert len(fact_path_ls) == 1
        tqdm.write('Processing Multiple SubGraphs..')
        for fn in tqdm(os.listdir(fact_path_ls[0])):
            d = parse_fact([joinpath(fact_path_ls[0], fn)], global_const2ind, global_ind2const,
                           keep_empty=cmd_args.keep_empty)
            d.name = fn
            if (len(d.unp_ls) == 0) or (len(d.bip_ls) == 0):
                tqdm.write('skip %s for zero-length unp or bip ls' % fn)
                continue
            for pn in d.unp_ls + d.bip_ls:
                pred2sgraph_dict[pn].append(d)

    else:
        raise ValueError

    return pred2sgraph_dict


def preprocess(pred_path, fact_path):
    pred_reg = re.compile(r'([\w]+)\(([^)]+)\)')

    for line in iterline(pred_path):
        m = pred_reg.match(line)
        assert m is not None

        pred_name = m.group(1)
        var_types = m.group(2).split(',')

        pred_register.add(Predicate(pred_name, var_types))
        TYPE_SET.update(var_types)

    fact_dict = dict((pred_name, set()) for pred_name in pred_register.pred_dict)
    pred2sgraph_dict = dict((pred_name, []) for pred_name in pred_register.pred_dict)

    def parse_fact(fp):
        avail_pred_ls = []

        for line in iterline(fp):
            parts = line.split('\t')
            val = int(parts[0])
            m = pred_reg.match(parts[1])
            assert m is not None

            pred_name = m.group(1)
            consts = m.group(2).split(',')

            if pred_name not in fact_dict:
                continue

            for ind, var_type in enumerate(pred_register.pred_dict[pred_name].var_types):
                const_dict.add_const(var_type, consts[ind])

            fact = (val, tuple(consts))
            fact_dict[pred_name].add(fact)
            avail_pred_ls.append(pred_name)

        return avail_pred_ls

    # a single file containing all facts, e.g. FB15K
    if os.path.isfile(fact_path):
        parse_fact(fact_path)

    # a folder containing fact files named with unique ids, e.g. GQA images
    elif os.path.isdir(fact_path):
        for fn in os.listdir(fact_path):
            pred_ls = parse_fact(joinpath(fact_path, fn))
            for pn in pred_ls:
                pred2sgraph_dict[pn].append(fn)

    else:
        raise ValueError

    fact_dict_sort = dict((pred_name, sorted(list(fact_dict[pred_name]), key=lambda x: x[1]))
                          for pred_name in fact_dict.keys())
    const_dict_sort = dict([(type_name, sorted(list(const_dict[type_name])))
                            for type_name in const_dict.constants.keys()])

    return fact_dict, fact_dict_sort, const_dict_sort, pred2sgraph_dict
