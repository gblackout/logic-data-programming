import json
from tqdm import tqdm
from os.path import join as joinpath
import pickle
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.image as mpimg
import numpy as np
import colorsys
import random
import os
from collections import Counter
import math


# [line_color, style, linewidth, alpha]
BOX_TYPE_DICT = {
    'dotted': ['gray', 'dotted', 2, 0.5],
    'default': ['', 'solid', 2, 1],
    'strong': ['', 'solid', 4, 1]
}


class GQADataset:

    def __init__(self, data_root):

        self.val_sGraph = json.load(open(joinpath(data_root, 'val_sceneGraphs.json')))
        self.train_sGraph = json.load(open(joinpath(data_root, 'train_sceneGraphs.json')))
        self.all_sGraph = dict([(k, v) for k, v in list(self.val_sGraph.items()) + list(self.train_sGraph.items())])
        self.img_dir = joinpath(data_root, 'images')

        # obj_dict, attr_set, relation_set, img_set = process_scene_graph([joinpath(fp, 'val_sceneGraphs.json'),
        #                                                                  joinpath(fp, 'train_sceneGraphs.json')])

        self.obj2name, self.name2obj = {}, {}
        self.preprocess_gqa()

    def preprocess_gqa(self):
        for k, v in self.all_sGraph.items():
            img_obj_dict = v['objects']

            for obj_id, obj_info in img_obj_dict.items():
                name = obj_info['name']
                self.obj2name[obj_id] = name
                if name in self.name2obj:
                    self.name2obj[name].append(obj_id)
                else:
                    self.name2obj[name] = [obj_id]



    def get_sGraph(self, img_id):
        return self.all_sGraph[img_id]

    def get_flatRel(self, img_id, filter_set=None, filter_lr=False):
        """

        :param img_id:
        :param filter_set:
            set of obj names. If not None, only return relations that involve objs in the set
        :return:
        """

        sGraph = self.get_sGraph(img_id)
        img_obj_dict = sGraph['objects']

        rel_dict = dict()

        name_set = {v['name'] for k,v in img_obj_dict.items()}
        if filter_set is not None:
            if not all([obj in name_set for obj in filter_set]):
                return rel_dict

        for sub_id, sub_info in img_obj_dict.items():
            rel_ls = sub_info['relations']
            for e in rel_ls:
                rel_name, rel_obj_id = e['name'], e['object']

                if filter_lr:
                    if (rel_name == 'to the left of') or (rel_name == 'to the right of'):
                        continue

                # dataset quality check
                assert rel_obj_id in img_obj_dict

                if filter_set is not None:
                    should_proceed = (rel_name in filter_set) or (img_obj_dict[rel_obj_id]['name'] in filter_set)
                    if not should_proceed:
                        continue

                if rel_name in rel_dict:
                    rel_dict[rel_name].append([sub_id, rel_obj_id])
                else:
                    rel_dict[rel_name] = [[sub_id, rel_obj_id]]

        return rel_dict

    def gen_img_boxes(self, img_id):

        sGraph = self.get_sGraph(img_id)
        img_obj_dict = sGraph['objects']

        box_ls, caption_ls = [], []
        for obj_id, obj_info in img_obj_dict.items():

            obj_name = obj_info['name']
            obj_attr = 'attr: %s' % ' '.join(obj_info['attributes'])
            obj_rel_ls = obj_info['relations']
            obj_rel = ' '.join(['%s(%s,%s)' % (e['name'], obj_name, img_obj_dict[e['object']]['name'])
                                for e in obj_rel_ls])

            # TODO debug
            obj_rel = ''

            box = [obj_info['x'], obj_info['y'], obj_info['w'], obj_info['h']]

            box_ls.append(box)
            caption_ls.append('%s\n%s\n%s' % (obj_name, obj_id, obj_rel))

        return box_ls, caption_ls

    def load_img(self, img_id):
        img_path = joinpath(self.img_dir, img_id + '.jpg')
        assert os.path.isfile(img_path), '%s not exists' % img_path
        img = mpimg.imread(img_path).copy()

        return img

    def check(self):

        img_set = set([fn[:-4] for fn in os.listdir(self.img_dir)])
        sGraph_set = set(list(self.all_sGraph.keys()))
        train_set = set(list(self.train_sGraph.keys()))
        valid_set = set(list(self.val_sGraph.keys()))

        intersect = img_set.intersection(sGraph_set)

        print('img set', len(img_set))
        print('sg set', len(sGraph_set))
        print('intersect', len(intersect))
        print('train', len(train_set))
        print('valid', len(valid_set))
        print('train_valid_inter', len(train_set.intersection(valid_set)))


def process_scene_graph(filepath_ls):

    obj_dict, attr_set, relation_set, img_set = {}, set(), set(), set()

    for filepath in filepath_ls:

        j = json.load(open(filepath))
        pbar = tqdm(total=len(j))

        for k, v in j.items():
            img_set.add(k)
            img_obj_dict = v['objects']

            for obj_id, obj_info in img_obj_dict.items():

                # assert obj_id not in img_set TODO obj_id overlaps img_id ???
                if obj_id in obj_dict:
                    assert obj_dict[obj_id] == obj_info['name']

                # if obj_info['name'] == 'banana':
                #     print(k, obj_id)

                obj_dict[obj_id] = obj_info['name']
                attr_set.update(obj_info['attributes'])

                img_rel_ls = obj_info['relations']
                for e in img_rel_ls:
                    relation_set.add(e['name'])

            pbar.update()

        pbar.close()

    return obj_dict, attr_set, relation_set, img_set


def show_imgs(img_id_ls, gqa, titles=None, cols=4, no_caption=False):

    if len(img_id_ls) < 4:
        cols = len(img_id_ls)

    titles = titles if titles is not None else [""] * len(img_id_ls)
    rows = len(img_id_ls) // cols + (0 if (len(img_id_ls) % cols == 0) else 1)
    plt.figure(figsize=(14, 14 * rows // cols))

    for ind, img_title in enumerate(zip(img_id_ls, titles)):
        img_id, title = img_title

        img = gqa.load_img(img_id)

        ax = plt.subplot(rows, cols, ind+1)
        ax.set_title(title, fontsize=9)
        ax.axis('off')

        box_ls, caption_ls = gqa.gen_img_boxes(img_id)
        caption_ls = ['']*len(box_ls) if no_caption else caption_ls
        type_ls = ['default'] * len(box_ls)
        color_ls = random_colors(1)*len(box_ls)

        draw_box(ax, box_ls, caption_ls, type_ls, color_ls)

        ax.imshow(img.astype(np.uint8))

    plt.tight_layout()
    plt.show()

    # img_ls = []
    # color_ls = random_colors(len(img_id_ls))
    # for ind, img_id in enumerate(img_id_ls):
    #     img_path = joinpath(data_dir, img_id+'.jpg')
    #     assert os.path.isfile(img_path), '%s not exists' % img_path
    #
    #     img = mpimg.imread(img_path).copy()
    #
    #     img = draw_box(img, [100, 100, 200, 200], color_ls[ind])
    #     img_ls.append(img)
    #
    # display_images(img_ls)



def display_images(images, titles=None, cols=4, cmap=None, norm=None,
                   interpolation=None):
    """Display the given set of images, optionally with titles.
    images: list or array of image tensors in HWC format.
    titles: optional. A list of titles to display with each image.
    cols: number of images per row
    cmap: Optional. Color map to use. For example, "Blues".
    norm: Optional. A Normalize instance to map values to colors.
    interpolation: Optional. Image interporlation to use for display.
    """

    if len(images) < 4:
        cols = len(images)

    titles = titles if titles is not None else [""] * len(images)
    rows = len(images) // cols + (0 if (len(images) % cols == 0) else 1)
    plt.figure(figsize=(14, 14 * rows // cols))
    i = 1
    for image, title in zip(images, titles):
        plt.subplot(rows, cols, i)
        plt.title(title, fontsize=9)
        plt.axis('off')
        plt.imshow(image.astype(np.uint8), cmap=cmap,
                   norm=norm, interpolation=interpolation)
        i += 1
    plt.show()


def random_colors(N, bright=True):
    """
    Generate random colors.
    To get visually distinct colors, generate them in HSV space then
    convert to RGB.
    """
    brightness = 1.0 if bright else 0.7
    hsv = [(i / N, 1, brightness) for i in range(N)]
    colors = list(map(lambda c: colorsys.hsv_to_rgb(*c), hsv))
    colors = list(map(lambda e:np.array(e), colors))
    random.shuffle(colors)
    return colors


def draw_box(ax, box_ls, caption_ls, box_type_ls, box_color_ls):
    """Draw 3-pixel width bounding boxes on the given image array.
    color: list of 3 int values for RGB.
    """

    for box, caption, box_type, box_color in zip(box_ls, caption_ls, box_type_ls, box_color_ls):
        x1, y1, w, h = box
        line_color, style, linewidth, alpha = BOX_TYPE_DICT[box_type]
        line_color = box_color if line_color == '' else line_color

        # box
        p = patches.Rectangle((x1, y1), w, h, linewidth=linewidth,
                              alpha=0.4, linestyle=style,
                              edgecolor=[0, 1.0, 1.0], facecolor='none')
        ax.add_patch(p)

        # # caption
        # ax.text(x1, y1, caption, size=10, verticalalignment='top',
        #         color='w', backgroundcolor="none",
        #         bbox={'facecolor': line_color, 'alpha': 0.5,
        #               'pad': 2, 'edgecolor': 'none'})

    # y1, x1, y2, x2 = box
    # image[y1:y1 + 2, x1:x2] = color
    # image[y2:y2 + 2, x1:x2] = color
    # image[y1:y2, x1:x1 + 2] = color
    # image[y1:y2, x2:x2 + 2] = color
    # return image


def person_car():
    data_root = '../../../dataset/gqa'
    gqa = GQADataset(data_root)

    for img_id, img_info in tqdm(gqa.all_sGraph.items()):
        img_obj_dict = img_info['objects']

        rel_dict = gqa.get_flatRel(img_id, filter_set={'car'})
        if len(rel_dict) == 0:
            continue

        with open('car', 'a') as f:
            rel_str = []
            for k, v in rel_dict.items():
                if ('left' in k) or ('right' in k):
                    continue
                for sub, obj in v:
                    rel_str.append('%s(%s,%s)' % (k, img_obj_dict[sub]['name'], img_obj_dict[obj]['name']))
            if len(rel_str) > 0:
                f.write('%s : %s\n' % (img_id, ','.join(rel_str)))


def display_car_data():
    data_root = '../../../dataset/gqa'
    gqa = GQADataset(data_root)

    for img_id, img_info in tqdm(gqa.all_sGraph.items()):
        img_obj_dict = img_info['objects']

        rel_dict = gqa.get_flatRel(img_id, filter_set={'car'}, filter_lr=True)

        if len(rel_dict) == 0:
            continue

        obj_ls = [(k, v['name']) for k, v in img_obj_dict.items()]
        obj_ls = sorted(obj_ls, key=lambda x:x[1])

        with open('car_img.txt', 'a') as f:
            # f.write('%s\n' % img_id)
            f.write('%s :\n' % img_id)

            cur_name = obj_ls[0][1]
            buf = []
            for obj_id, obj_name in obj_ls:
                if obj_name == cur_name:
                   buf.append(obj_id)
                else:
                    f.write('\t%s : %s\n' % (cur_name, ' '.join(buf)))
                    buf = [obj_id]
                    cur_name = obj_name

            if len(buf) > 0:
                f.write('\t%s : %s\n' % (cur_name, ' '.join(buf)))

            rel_dict = gqa.get_flatRel(img_id, filter_lr=True)
            for rel_name, obj_id_ls in rel_dict.items():
                obj_str_ls = ['(%s,%s)' % (e[0], e[1]) for e in obj_id_ls]
                f.write('\t%s : %s\n' % (rel_name, ' '.join(obj_str_ls)))


def obj_data():
    data_root = '../../../dataset/gqa'
    gqa = GQADataset(data_root)
    obj_cnter = Counter()
    filter_under = 0

    for img_id, img_info in tqdm(gqa.all_sGraph.items()):
        img_obj_dict = img_info['objects']

        obj_cnter.update([v['name'] for k,v in img_obj_dict.items()])

    with open('obj_freq.txt', 'w') as f:
        f.write('total obj %i\n' % sum(v for k,v in obj_cnter.items()))
        for k,v in obj_cnter.most_common():
            if v > filter_under:
                f.write('%s %i\n' % (k, v))


def rel_data():
    data_root = '../../../dataset/gqa'
    gqa = GQADataset(data_root)
    rel_cnter = Counter()
    filter_under = 0

    # filter_under = 2000
    #
    # un_mergDict = {}
    # with open('un_merge.txt') as f:
    #     for line in f:
    #         merge_name, parts = line.split(': ')
    #         names = parts.strip().split(',')
    #         for name in names:
    #             un_mergDict[name] = merge_name

    for img_id, img_info in tqdm(gqa.all_sGraph.items()):

        rel_dict = gqa.get_flatRel(img_id, filter_lr=True)
        for k, v in rel_dict.items():
            rel_cnter.update([k]*len(v))

    with open('rel_freq.txt', 'w') as f:
        f.write('total rel %i\n' % sum(v for k,v in rel_cnter.items()))
        for k,v in rel_cnter.most_common():
            if v > filter_under:
                f.write('%s %i\n' % (k, v))

import pickle

def prep_car_data(data_root = '../../../dataset/gqa/scene_graph'):
    output_path = '../data/gqa'

    fact_sgraph_path = joinpath(output_path, 'fact_domains')
    valid_sgraph_path = joinpath(output_path, 'valid_domains')
    test_sgraph_path = joinpath(output_path, 'test_domains')

    os.mkdir(output_path)
    os.mkdir(fact_sgraph_path)
    os.mkdir(valid_sgraph_path)
    os.mkdir(test_sgraph_path)

    gqa = GQADataset(data_root)
    filter_under = 1500
    un_mergDict, rel_mergDict = {}, {}
    un_filterSet, rel_filterSet = set(), set()

    # with open('car_img.txt') as f:
    #     img_id_ls = [line.strip() for line in f]

    with open('un_merge.txt') as f:
        for line in f:
            merge_name, parts = line.split(': ')
            names = parts.strip().split(',')
            for name in names:
                un_mergDict[name] = merge_name
    with open('rel_merge.txt') as f:
        for line in f:
            merge_name, parts = line.split(': ')
            names = parts.strip().split(',')
            for name in names:
                rel_mergDict[name] = merge_name

    freq_dict = {}
    # with open('car_un_freq.txt') as f:
    with open('obj_freq.txt') as f:
        for line in f:
            parts = line.strip().split(' ')
            freq = int(parts[-1])
            name = ' '.join(parts[:-1])
            if name in un_mergDict:
                name = un_mergDict[name]

            if name in freq_dict:
                freq_dict[name] += freq
            else:
                freq_dict[name] = freq
    un_filterSet.update([k for k, v in freq_dict.items() if v < filter_under])

    freq_dict = {}
    # with open('car_rel_freq.txt') as f:
    with open('rel_freq.txt') as f:
        for line in f:
            parts = line.strip().split(' ')
            freq = int(parts[-1])
            name = ' '.join(parts[:-1])
            if name in rel_mergDict:
                name = rel_mergDict[name]

            if name in freq_dict:
                freq_dict[name] += freq
            else:
                freq_dict[name] = freq
    rel_filterSet.update([k for k, v in freq_dict.items() if v < filter_under])

    # 8/1/1 split
    num_sgraphs = len(gqa.all_sGraph)
    valid_ind = math.ceil(num_sgraphs * 0.8)
    test_ind = math.ceil(num_sgraphs * 0.9)
    sgraph_path_ls = [fact_sgraph_path, valid_sgraph_path, test_sgraph_path]

    un_pred_set, bi_pred_set = set(), set()
    cur_ind = 0
    # ht_dict, th_dict = {}, {}
    for img_id, _ in tqdm(gqa.all_sGraph.items()):

        # if cur_ind < math.ceil(valid_ind * 0.9999):
        #     cur_ind += 1
        #     continue

        sgraph_path = 0 if cur_ind < valid_ind else 1
        sgraph_path = sgraph_path if cur_ind < test_ind else 2
        sgraph_path = sgraph_path_ls[sgraph_path]

        # if cur_ind == valid_ind:
        #     continue

        sgraph = gqa.get_sGraph(img_id)
        objs_dict = sgraph['objects']
        rel_dict = gqa.get_flatRel(img_id, filter_lr=True)
        fact_set = set()

        # sgraph_unp_set = [v['name'] for k, v in objs_dict.items()]
        # sgraph_unp_set = [(un_mergDict[e] if e in un_mergDict else e) for e in sgraph_unp_set]
        # sgraph_unp_set = set([e for e in sgraph_unp_set if (e not in un_filterSet)])

        for rel_name, sub_obj_id_ls in rel_dict.items():
            if rel_name in rel_filterSet:
                continue

            for sub_id, obj_id in sub_obj_id_ls:
                sub_name, obj_name = objs_dict[sub_id]['name'], objs_dict[obj_id]['name']
                sub_name = un_mergDict[sub_name] if sub_name in un_mergDict else sub_name
                obj_name = un_mergDict[obj_name] if obj_name in un_mergDict else obj_name
                if (sub_name in un_filterSet) or (obj_name in un_filterSet):
                    continue

                rel_name = rel_mergDict[rel_name] if rel_name in rel_mergDict else rel_name

                rel_name = rel_name.replace(' ', '_')
                sub_name = sub_name.replace(' ', '_')
                obj_name = obj_name.replace(' ', '_')

                un_pred_set.add('%s(type)' % sub_name)
                un_pred_set.add('%s(type)' % obj_name)
                bi_pred_set.add('%s(type,type)' % rel_name)

                fact_set.add('1\t%s(%s)' % (sub_name, sub_id))
                fact_set.add('1\t%s(%s)' % (obj_name, obj_id))
                fact_set.add('1\t%s(%s,%s)' % (rel_name, sub_id, obj_id))

                # if rel_name in ht_dict:
                #     if sub_name in ht_dict[rel_name]:
                #         if obj_name in ht_dict[rel_name][sub_name]:
                #             ht_dict[rel_name][sub_name][obj_name] += 1
                #         else:
                #             ht_dict[rel_name][sub_name][obj_name] = 1
                #     else:
                #         ht_dict[rel_name][sub_name] = dict([(obj_name, 1)])
                # else:
                #     ht_dict[rel_name] = dict([(sub_name, dict([(obj_name, 1)]))])
                #
                # if rel_name in th_dict:
                #     if obj_name in th_dict[rel_name]:
                #         if sub_name in th_dict[rel_name][obj_name]:
                #             th_dict[rel_name][obj_name][sub_name] += 1
                #         else:
                #             th_dict[rel_name][obj_name][sub_name] = 1
                #     else:
                #         th_dict[rel_name][obj_name] = dict([(sub_name, 1)])
                # else:
                #     th_dict[rel_name] = dict([(obj_name, dict([(sub_name, 1)]))])


        if len(fact_set) > 0:

            with open(joinpath(sgraph_path, img_id), 'w') as f:
                for fact in fact_set:
                    f.write('%s\n' % fact)

        cur_ind += 1

    # for rel_name in ht_dict:
    #     for sub_name in ht_dict[rel_name]:
    #         ht_dict[rel_name][sub_name] = sorted([(pn, cnt) for pn, cnt in ht_dict[rel_name][sub_name].items()],
    #                                                   key= lambda x:x[1], reverse=True)
    #
    # for rel_name in th_dict:
    #     for obj_name in th_dict[rel_name]:
    #         th_dict[rel_name][obj_name] = sorted([(pn, cnt) for pn, cnt in th_dict[rel_name][obj_name].items()],
    #                                                   key= lambda x:x[1], reverse=True)

    # pickle.dump(ht_dict, open('gqa_ht_dict', 'wb'))
    # pickle.dump(th_dict, open('gqa_th_dict', 'wb'))

    for pn in list(un_pred_set) + list(bi_pred_set):
        with open(joinpath(output_path, 'pred.txt'), 'a') as f:
            f.write('%s\n' % pn)



if __name__ == '__main__':
    import sys
    random.seed(10)
    prep_car_data(sys.argv[1])

