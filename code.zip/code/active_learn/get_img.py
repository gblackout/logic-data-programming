import matplotlib.pyplot as plt
import pickle
from tqdm import tqdm
import numpy as np

match_dict = pickle.load(open('../data/gqa/gqa_rcnn_feat/match_dict', 'rb'))

for k, ls in match_dict.items():
    img_dict = {}
    for res in tqdm(ls):
        img = plt.imread('../../../dataset/gqa/images/'+res[1]+'.jpg')

        if len(img.shape) == 2:
            img = np.stack([img, img, img], axis=-1)

        assert len(img.shape) == 3, res[1] + str(img.shape)
        img = img[res[3][1]:res[3][3], res[3][0]:res[3][2], :]
        img_dict[res[2]] = img

    pickle.dump(img_dict, open('%s_img_dict' % str(k), 'wb'))
