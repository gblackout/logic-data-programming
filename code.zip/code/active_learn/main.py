import os, sys

sys.path.append('%s/..' % os.path.dirname(os.path.realpath(__file__)))

from common.cmd_args import cmd_args
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from common.predicate import pred_register
from data_process.dataset import SubGraphDataset
from common.utils import make_run_dir, iterline, make_opt_env, makedir
from tqdm import tqdm
from model.Models import RuleLearner, TabularPhiList
import common.phi as phi
from os.path import join as joinpath
import random
import time
from typing import Set
from copy import deepcopy
from active_learn.mlp import ModelEnv
import re
import pickle
import itertools
from active_learn.gcn import sgraph2gcn_data


class NTN(nn.Module):

    def __init__(self, input_dim, latent_dim):
        super(NTN, self).__init__()

        self.W = nn.Bilinear(input_dim, input_dim, latent_dim, bias=False).to(cmd_args.device)
        self.V = nn.Linear(input_dim, latent_dim, bias=True).to(cmd_args.device)
        self.u = nn.Linear(latent_dim, 1, bias=True).to(cmd_args.device)

    def forward(self, x, xx):
        """

        :param embeddings:
            batch of entity embeddings of size (n, num_args, input_dim)
        :return:
            unnormalized output of size (n)
        """

        # embeddings = embeddings.view(embeddings.size(0), -1)  # (n, num_args*input_dim)
        tmp = torch.tanh(self.W(x, xx) + self.V(x) + self.V(xx))  # (n, latent_dim)
        score = self.u(tmp)  # (n)

        return score


def init_model():
    unp_ls = [(pn, phi.TabularPhi(pn)) for pn in pred_register.pred_dict if pred_register.is_unp(pn)]
    bip_ls = [(pn, phi.TabularPhi(pn)) for pn in pred_register.pred_dict if not pred_register.is_unp(pn)]

    phi_list = TabularPhiList(unp_ls, bip_ls).to(cmd_args.device)
    rule_learner = RuleLearner(len(unp_ls) + len(bip_ls), phi_list).to(cmd_args.device)

    return rule_learner


class Task:

    def __init__(self, model_env: ModelEnv, p_star, dataset: SubGraphDataset, output_path):
        self.model_env = model_env
        self.rule_learner = init_model()
        self.p_star = p_star
        self.output_path = joinpath(output_path, p_star)
        makedir(self.output_path, remove_old=False)
        self.dataset = dataset
        self.rule_rank_ls = []
        self.keep_ls = []
        self.task_p2sgraph_dict = self.dataset.fact_pred2sgraph_dict

        total_batches = self.dataset.get_numBatches(self.task_p2sgraph_dict,
                                                    self.p_star, cmd_args.batch_size)
        self.warmup_size = cmd_args.warm_up_size * (total_batches if cmd_args.warm_up_size < 1 else 1)
        self.warmup_size = int(self.warmup_size)
        self.neg_samples = []

    def write_log(self, fn, msg, stdout=True, overwrite=False):
        mode = 'w' if overwrite else 'a'
        with open(joinpath(self.output_path, fn), mode) as f:
            f.write('%s\n' % msg)
        if stdout:
            tqdm.write(msg)

    def load_rule_learner(self):
        if not cmd_args.model_load_path:
            tqdm.write('pre-trained model not found')
            return False

        model_path = joinpath(cmd_args.model_load_path, self.p_star, '%s_rule_learner' % self.p_star)
        rule_path = joinpath(cmd_args.model_load_path, self.p_star, 'evaled_rule.txt')

        keep_ls_path = joinpath(cmd_args.model_load_path, self.p_star, 'keep_ls')
        neg_samples_path = joinpath(cmd_args.model_load_path, self.p_star, 'neg_samples')
        if os.path.isfile(keep_ls_path):
            self.keep_ls = pickle.load(open(keep_ls_path, 'rb'))
        if os.path.isfile(neg_samples_path):
            self.neg_samples = pickle.load(open(neg_samples_path, 'rb'))

        if (os.path.isfile(model_path) or cmd_args.skip_model) and os.path.isfile(rule_path):
            if os.path.isfile(model_path):
                self.rule_learner.load_state_dict(torch.load(model_path))

            lines = [l for l in iterline(rule_path)]
            rule_reg = re.compile(r'([.\d]+) / ([.\d]+) R1 ([.\d]+) TR1 ([.\d]+): ([^:]+)')
            for line in lines:
                m = rule_reg.match(line)
                assert m
                rule_name, ls = m.group(5), list(map(float, m.group(1, 2, 3, 4)))
                self.rule_rank_ls.append([rule_name, ls])

            tqdm.write('pre-trained model loaded')
            return True

        tqdm.write('pre-trained model not found')
        return False

    def learn_rule(self, allowed_p_set, verbose=True):
        tqdm.write('train rule learner for %s' % self.p_star)

        flag = self.load_rule_learner()
        if flag:
            tqdm.write('skip training')
            return

        optimizer, scheduler, monitor = make_opt_env([self.rule_learner.parameters()])
        tgt_pred_ls = [self.p_star]
        skip_prob_dict = dict((pn, 0) for pn in tgt_pred_ls)
        shouldstop = False
        st = time.time()
        for cur_epoch in range(cmd_args.num_epochs):

            if shouldstop:
                break

            num_batches, epoch_iterator = self.dataset.sample(self.task_p2sgraph_dict,
                                                              cmd_args.batch_size,
                                                              allow_recursion=cmd_args.allow_recursion,
                                                              rotate=cmd_args.rotate,
                                                              keep_array=cmd_args.kb,
                                                              tgt_pred_ls=tgt_pred_ls,
                                                              bg_sgraph=None,
                                                              allowed_p_set=allowed_p_set)

            pbar = tqdm(total=num_batches)
            acc_loss = 0.0
            cur_batch = 0
            for input_x, input_y, unp_ls, bip_ls, p_star, _ in epoch_iterator:

                if cur_batch >= self.warmup_size:  # NOTE warmup limit induced here:
                    break

                skip = cmd_args.skip_trained and ((skip_prob_dict[p_star] > 0.5) and
                                                  (random.random() < skip_prob_dict[p_star]))
                if not skip:
                    # [num_sample] loss
                    sample_val_ls, mask_ls, name_ls = self.rule_learner(input_x, input_y,
                                                                        pred_register.pred2ind[p_star],
                                                                        unp_ls, bip_ls, cmd_args.gumbelmax_temp,
                                                                        cmd_args.num_samples)

                    if verbose:
                        tqdm.write('%s <- %s' % (p_star, name_ls[0][-1][-1][0]))

                    cand_val = torch.cat([val_ls[-1] for val_ls in sample_val_ls], dim=-1)
                    input_y = input_y.to(cmd_args.device)

                    num_cand = cand_val.size(-1)

                    loss = F.binary_cross_entropy(cand_val.clamp(max=1), input_y.view(-1, 1).expand(-1, num_cand))

                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()
                    scheduler.step(loss)

                pbar.update()
                acc_loss += (acc_loss / (cur_batch + 1e-6)) if skip else loss.item()
                cur_batch += 1
                pbar.set_description('Epoch %i, avg loss: %.4f' % (cur_epoch, acc_loss / cur_batch))

            tqdm.write('evaluating..')
            cand_rank_ls, global_r = eval_rule_learner(self.rule_learner, self.dataset, tgt_pred_ls,
                                                       self.task_p2sgraph_dict, allowed_p_set, self.warmup_size)

            update_rule = -global_r < monitor.cur_best
            shouldstop = monitor.update(-global_r)
            if update_rule:
                self.rule_rank_ls = cand_rank_ls
                msg = 'Epoch %i time %.4f %.4f' % (cur_epoch, time.time() - st, global_r)
                self.save_snapshot(msg)

            pbar.close()

    def save_snapshot(self, msg):
        torch.save(self.rule_learner.state_dict(), joinpath(self.output_path, self.p_star + '_rule_learner'))
        with open(joinpath(self.output_path, 'best_rule.txt'), 'w') as f:
            f.write('%s\n' % msg)
            f.write(self.rank_ls2str(self.rule_rank_ls))

    def rank_ls2str(self, rule_rank_ls):
        return '\n'.join('%.1f / %.1f R1 %.1f TR1 %.1f: %s' % (ls[0], ls[1], ls[2], ls[3], rule_name)
                         for rule_name, ls in rule_rank_ls)

    def infer_sample(self, allowed_p_set):
        # gather oracle labeled rules into dict
        infer_rule_dict = dict([(e[0], e[1][-1]) for e in self.rule_rank_ls if e[1][-1] > 0])

        # tqdm.write('%s pos %i / %i, neg %i / %i' % (self.p_star, sum(self.keep_ls), len(self.keep_ls), len(self.neg_samples), len(self.keep_ls)))

        if (len(self.keep_ls) == 0) or (cmd_args.force_infer):
            tqdm.write('rule inference for %s ...' % self.p_star)

            if len(infer_rule_dict) == 0:
                self.write_log('WARNING.txt', 'No supervision provided for task' + self.p_star)

            self.keep_ls = []
            cur_batch = 0
            # infer over hidden set and randomly filter the sample w.r.t the applied rule gndtruth R1 score
            for infer_res in hard_infer(self.rule_learner, self.dataset,
                                        [self.p_star], self.task_p2sgraph_dict,
                                        allowed_p_set, None):

                p_star, rule_name, hit, sgraph_name, unp_ls, bip_ls, _ = infer_res
                cur_batch += 1

                # keep those in warmup set
                if cur_batch < self.warmup_size:
                    keep_sample = True
                else:
                    # exclude those not using the labelled rule
                    if rule_name not in infer_rule_dict:
                        keep_sample = False
                    else:
                        # keep those using labelled rule randomly
                        keep_sample = random.random() < infer_rule_dict[rule_name]

                self.keep_ls.append(keep_sample)

                # # TODO debug
                # if cur_batch == 50:
                #     break

            self.write_log('log.txt', 'task %s rule inference results: (%i + %i) / %i' %
                           (self.p_star, self.warmup_size, sum(self.keep_ls) - self.warmup_size, cur_batch))

            with open(joinpath(self.output_path, 'keep_ls'), 'wb') as f:
                pickle.dump(self.keep_ls, f)

            # TODO ad hoc neg samples
            tqdm.write('rule inference neg samples for %s ...' % self.p_star)
            cur_batch = 0
            self.neg_samples = []
            for infer_res in hard_infer(self.rule_learner, self.dataset,
                                        [self.p_star], self.task_p2sgraph_dict,
                                        allowed_p_set, None, on_neg=True):

                p_star, rule_name, hit, sgraph_name, unp_ls, bip_ls, neg_const = infer_res
                if rule_name not in infer_rule_dict:
                    keep_sample = False
                else:
                    if hit < 0.1:
                        keep_sample = False
                    # accepting miss-classified samples
                    else:
                        # keep those using labelled rule randomly
                        keep_sample = random.random() < infer_rule_dict[rule_name]

                if keep_sample:
                    self.neg_samples.append(neg_const)

                cur_batch += 1

            self.write_log('log.txt', 'task %s rule inference neg results: %i / %i' %
                           (self.p_star, len(self.neg_samples), cur_batch))

            # TODO debug
            with open(joinpath(self.output_path, 'neg_samples'), 'wb') as f:
            # with open(joinpath('../run_logs/al25-run1', self.p_star, 'neg_samples'), 'wb') as f:
                pickle.dump(self.neg_samples, f)


def learn_model(task_ls, dataset, model_env, model_name, allowed_p_set):
    tqdm.write('learn %s...' % model_name)

    # TODO ad hoc fill exceeding budget as samples
    if cmd_args.fill_budget:
        add_num = cmd_args.budget - 5
        if add_num > 0:
            tqdm.write('fill in budget for %i' % add_num)
            for task in task_ls:
                cnt = 0
                for i in range(len(task.keep_ls)):
                    if not task.keep_ls[i]:
                        task.keep_ls[i] = True
                        cnt += 1
                    if cnt >= add_num:
                        break

    def iter_sample(p2graph_dict, p_star, train=True):
        for sgraph in p2graph_dict[p_star]:
            if train:
                unp_ls, bip_ls = [pn for pn in sgraph.unp_ls if pn in allowed_p_set], \
                                 [pn for pn in sgraph.bip_ls if pn in allowed_p_set]
                if (len(unp_ls) == 0) or (len(bip_ls) < 1):
                    continue

                for val, consts in sgraph.fact_dict[p_star]:
                    if model_name == 'mlp':
                        yield consts[0], p_star
                    else:
                        nodes, gcn_edges = sgraph2gcn_data(sgraph, consts[0], None)
                        yield (consts[0], nodes, gcn_edges), p_star


            else:
                for val, consts in sgraph.fact_dict[p_star]:
                    if model_name == 'mlp':
                        yield consts[0], p_star
                    else:
                        nodes, gcn_edges = sgraph2gcn_data(sgraph, consts[0], None)
                        yield (consts[0], nodes, gcn_edges), p_star

    def iter_sample2(p2graph_dict, mode):
        for task in task_ls:

            if mode == 'train':
                acceptsample = lambda x: task.keep_ls[x]
            elif mode == 'valid':
                acceptsample = lambda x: x < task.warmup_size
            else:
                acceptsample = lambda x: True

            ind = 0
            cnt, pos_num = 0, 0
            for sample in iter_sample(p2graph_dict, task.p_star, train=mode == 'train'):
                # NOTE we filter samples using keep_ls
                if acceptsample(ind):
                    yield sample
                    cnt += 1
                ind += 1
            pos_num = cnt

            # NOTE ad-hoc add neg samples
            if mode == 'train':
                for neg_const in task.neg_samples:
                    if model_name == 'mlp':
                        yield neg_const, task.p_star
                    else:
                        pass # TODO ad hoc
                        # nodes, gcn_edges = sgraph2gcn_data(sgraph, neg_const, None)
                        # yield (neg_const, nodes, gcn_edges), task.p_star
                    cnt += 1

            # NOTE ad hoc sample fill
            pos_prob = float(pos_num) / (float(pos_num) + len(task.neg_samples))
            has_neg = len(task.neg_samples) > 0
            get_neg = itertools.cycle(task.neg_samples)
            while cnt < cmd_args.min_samples:
                ind = 0
                for sample in iter_sample(p2graph_dict, task.p_star, train=mode == 'train'):
                    if acceptsample(ind):
                        if (random.random() < pos_prob) or (not has_neg):
                            yield sample
                        else:
                            if model_name == 'mlp':
                                yield next(get_neg), task.p_star
                            else:
                                pass  # TODO ad hoc

                        cnt += 1

                    if cnt >= cmd_args.min_samples:
                        break
                    ind += 1

    train_iter_gen = lambda: iter_sample2(dataset.fact_pred2sgraph_dict, 'train')
    valid_iter_gen = lambda: iter_sample2(dataset.valid_pred2sgraph_dict, 'valid')
    test_iter_gen = lambda: iter_sample2(dataset.test_pred2sgraph_dict, 'test')

    model_env.train_model(model_name, [task.p_star for task in task_ls], train_iter_gen, valid_iter_gen, test_iter_gen)


def hard_infer(rule_learner, dataset, tgt_pred_ls, p2sgraph_dict, allowed_p_set, warmup_size, on_neg=False):
    infer_numSample = 1
    bsize = 1
    bak1, bak2 = cmd_args.hard_sample, cmd_args.sample_neg
    cmd_args.hard_sample = True
    cmd_args.sample_neg = False

    with torch.no_grad():
        # rotate over data w.r.t each p_star
        num_batches, epoch_iterator = dataset.sample(p2sgraph_dict,
                                                     batch_size=bsize,
                                                     allow_recursion=cmd_args.allow_recursion,
                                                     rotate=False,
                                                     keep_array=cmd_args.kb,
                                                     tgt_pred_ls=tgt_pred_ls,
                                                     bg_sgraph=None,
                                                     allowed_p_set=allowed_p_set)
        cur_batch = 0
        for input_x, input_y, unp_ls, bip_ls, p_star, sgraph_name in epoch_iterator:

            if warmup_size and (cur_batch >= warmup_size):
                break

            neg_const = None
            if on_neg:
                sgraph = dataset.sgraph_dict[sgraph_name]
                if len(sgraph.unp_ls) > 1:
                    neg_unp = p_star
                    while neg_unp == p_star:
                        neg_unp = random.choice(sgraph.unp_ls)
                    val, consts = random.choice(sgraph.fact_dict[neg_unp])
                    input_x[1][0, 0, :] = 0
                    input_x[1][0, 0, sgraph.const2ind_dict[consts[0]]] = 1
                    neg_const = consts[0]

            sample_val_ls, mask_ls, name_ls = rule_learner(input_x, input_y,
                                                           pred_register.pred2ind[p_star],
                                                           unp_ls, bip_ls, None,
                                                           infer_numSample)

            cand_val = torch.cat([val_ls[-1] for val_ls in sample_val_ls], dim=-1)
            num_cand = cand_val.size(-1)
            input_y = input_y.to(cmd_args.device).view(-1, 1).expand(-1, num_cand)
            prediction = (cand_val >= 0.5).type(torch.float)
            intersect = ((prediction > 0) * (input_y > 0)).type(torch.float)
            cur_batch += 1

            yield p_star, name_ls[0][-1][-1][0], intersect.sum().item(), sgraph_name, unp_ls, bip_ls, neg_const

    cmd_args.hard_sample, cmd_args.sample_neg = bak1, bak2


def eval_rule_learner(rule_learner, dataset, tgt_pred_ls, p2sgraph_dict, allowed_p_set, warmup_size):
    rule_ls = [infer_res for infer_res in hard_infer(rule_learner, dataset, tgt_pred_ls, p2sgraph_dict,
                                                     allowed_p_set, warmup_size)]

    cnter = {}
    for _, rule_name, hit, sgraph_name, unp_ls, bip_ls, _ in rule_ls:
        if rule_name in cnter:
            cnter[rule_name][0] += hit
            cnter[rule_name][1] += 1
        else:
            cnter[rule_name] = [hit, 1, 0, 0]  # [hits, y_cnt, warmup_R1, gndtruth_R1]
    for rule_name, ls in cnter.items():
        ls[2] = ls[0] / float(ls[1])
    # sort rule by firstly the applied cnt, secondly the warmup R1 score
    rule_rank_ls = sorted(list(cnter.items()), key=lambda x: (x[1][1], x[1][2]), reverse=True)

    global_r = sum(v[0] for v in cnter.values()) / float(len(rule_ls))

    return rule_rank_ls, global_r


def call_syn_oracle(dataset: SubGraphDataset, task: Task, allowed_p_set: Set[str]):
    tqdm.write('call oracle for %s' % task.p_star)
    # evaluate rule learner on the entire set as if were given to human

    # TODO ad hoc
    gndtruth_rule_path = joinpath(cmd_args.model_load_path, task.p_star, 'gndtruth_rule.txt')
    if os.path.isfile(gndtruth_rule_path):
        tqdm.write('loading gndtruth for %s' % task.p_star)
        lines = [l for l in iterline(gndtruth_rule_path)]
        rule_reg = re.compile(r'([.\d]+) / ([.\d]+) R1 ([.\d]+) TR1 ([.\d]+): ([^:]+)')
        gndtruth_rank_ls = []
        for line in lines:
            m = rule_reg.match(line)
            assert m
            rule_name, ls = m.group(5), list(map(float, m.group(1, 2, 3, 4)))
            gndtruth_rank_ls.append([rule_name, ls])
    else:
        tqdm.write('inferrring gndtruth for %s' % task.p_star)
        gndtruth_rank_ls, global_r = eval_rule_learner(task.rule_learner, dataset, [task.p_star],
                                                       dataset.fact_pred2sgraph_dict, allowed_p_set, None)

    gndtruth_rank_dict = dict(gndtruth_rank_ls)

    # import num of budget of supervisions from oracle
    cnt = 0
    # TODO ad hoc setting max rule num to 5 and fill out res
    budget = min(5, cmd_args.budget) if cmd_args.fill_budget else cmd_args.budget
    for rule_name, ls in task.rule_rank_ls[:budget]:
        if rule_name in gndtruth_rank_dict:
            cnt += 1
            ls[3] = gndtruth_rank_dict[rule_name][2]  # reveal gndtruth R1 to the learner

    if cnt == 0:
        task.write_log('WARNING.txt', 'no supervision available!')

    task.write_log('gndtruth_rule.txt', task.rank_ls2str(gndtruth_rank_ls), False, overwrite=True)
    task.write_log('evaled_rule.txt', task.rank_ls2str(task.rule_rank_ls), False, overwrite=True)


def active_train():
    output_path, model_path = make_run_dir(cmd_args)
    model_env = ModelEnv(deepcopy(cmd_args), output_path)
    model_name = cmd_args.learner
    dataset = SubGraphDataset(cmd_args.data_root)

    allowed_unp_ls = [pn for pn in iterline('allowed_unp_ls.txt')]
    # NOTE for now, allow using all relations
    # allowed_bip_ls = [pn for pn in iterline('allowed_bip_ls.txt')] + [IDENT_PHI]
    allowed_bip_ls = [pn for pn in pred_register.pred_dict if not pred_register.is_unp(pn)]
    allowed_p_set = set(pn for p_ls in [allowed_unp_ls, allowed_bip_ls] for pn in p_ls)

    tgt_pred_ls = [pn for pn in iterline('tgt_pred_ls.txt')]

    task_dict = {}
    for p_star in tgt_pred_ls:
        task = Task(model_env, p_star, dataset, output_path)
        task_dict[p_star] = task

        task.learn_rule(allowed_p_set)

        call_syn_oracle(dataset, task, allowed_p_set)

        task.infer_sample(allowed_p_set)

    learn_model([task_dict[pn] for pn in tgt_pred_ls], dataset, model_env, model_name, allowed_p_set)


if __name__ == '__main__':
    random.seed(cmd_args.seed)
    np.random.seed(cmd_args.seed)
    torch.manual_seed(cmd_args.seed)

    # TODO adhoc
    # cmd_args.warm_up_size = 25
    # cmd_args.budget = 1
    # cmd_args.force_infer = True
    # cmd_args.run_name = 'al25'
    # cmd_args.model_load_path = '../run_logs/al25_b1-run1'  # TODO debug
    # cmd_args.model_load_path = './'
    # cmd_args.skip_model = True

    active_train()

    # train_mlp()
