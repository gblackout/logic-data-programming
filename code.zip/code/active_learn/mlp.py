import os, sys

sys.path.append('%s/..' % os.path.dirname(os.path.realpath(__file__)))

from common.cmd_args import cmd_args
import torch
import torch.nn as nn
import torch.nn.functional as F
import pickle
from typing import Iterator, Callable
from common.utils import make_run_dir, iterline, make_opt_env
from tqdm import tqdm
from data_process.dataset import SubGraphDataset
from os.path import join as joinpath
import math
from copy import deepcopy
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np
import random
import torch_geometric.data
from active_learn.gcn import GCN, sgraph2gcn_data


class GQAImage:

    def __init__(self):
        self.transformations = transforms.Compose([
            transforms.Resize(255),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        match_dict = pickle.load(open('../data/gqa/gqa_rcnn_feat/match_dict', 'rb'))
        self.match_dict = {}
        for k, ls in match_dict.items():
            for res in ls:
                self.match_dict[res[2]] = ['../../../dataset/gqa/images/' + res[1] + '.jpg', res[3]]

    def get_tensor(self, id_ls):

        img_buf = []
        for obj_id in id_ls:
            img_path, xy = self.match_dict[obj_id]

            img = plt.imread(img_path)
            if len(img.shape) == 2:
                img = np.stack([img, img, img], axis=-1)

            if xy[0] > img.shape[0]:
                xy[0] = img.shape[0]

            if xy[1] > img.shape[1]:
                xy[1] = img.shape[1]

            # img = img.crop(xy[0], xy[3], xy[2], xy[1])
            cimg = img[xy[1]:xy[3], xy[0]:xy[2], :]
            img_buf.append(self.transformations(Image.fromarray(cimg)))

            # try:
            #     img_buf.append(self.transformations(Image.fromarray(cimg)))
            # except:
            #     print(img_path)
            #     print(xy)
            #     print(obj_id)
            #     print(img.shape)
            #     print(cimg.shape)
            #     sys.exit(1)

        return torch.stack(img_buf, dim=0)


class CNN(nn.Module):

    def __init__(self):
        super(CNN, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(64, 192, kernel_size=5, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(192, 384, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
        )
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        # self.classifier = nn.Sequential(
        #     nn.Dropout(),
        #     nn.Linear(256 * 6 * 6, 4096),
        #     nn.ReLU(inplace=True),
        #     nn.Dropout(),
        #     nn.Linear(4096, 4096),
        #     nn.ReLU(inplace=True),
        #     nn.Linear(4096, num_classes),
        # )

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        # x = self.classifier(x)
        return x


class MLP(nn.Module):

    def __init__(self, input_dim, latent_dim, num_class):
        super(MLP, self).__init__()

        # self.fc1 = nn.Linear(input_dim, latent_dim).to(cmd_args.device)
        # self.fc2 = nn.Linear(latent_dim, num_class).to(cmd_args.device)

        self.classifier = nn.Sequential(
            nn.Dropout(),
            nn.Linear(input_dim, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_class),
        ).to(cmd_args.device)

        # self.classifier = nn.Sequential(
        #     nn.Linear(input_dim, 4096),
        #     nn.ReLU(inplace=True),
        #     nn.Linear(4096, 4096),
        #     nn.ReLU(inplace=True),
        #     nn.Linear(4096, num_class),
        # ).to(cmd_args.device)

    def forward(self, rcnn_features):

        # x = F.relu(self.fc1(rcnn_features))
        # output = self.fc2(x)
        output = self.classifier(rcnn_features)

        return output


class ModelEnv:
    def __init__(self, config, output_path):

        # TODO hard code
        config.batch_size = 64
        config.num_batches_per_valid = 50000
        config.lr_decay_patience = 1000
        config.embedding_size = 512
        config.num_epochs = 4000
        config.patience = 200
        # config.l2_coef = 0.01
        self.config = config
        self.output_path = output_path

        rcnn_feat_path = joinpath(cmd_args.data_root, 'gqa_rcnn_feat')
        self.feature_mat = torch.load(joinpath(rcnn_feat_path, 'obj_feature.pt')).to(cmd_args.device)  # (num_ent, 2048)
        self.feature_mat = F.normalize(self.feature_mat, dim=-1)
        self.feature_mat += (torch.rand_like(self.feature_mat) - 0.5) / cmd_args.noise_level

        self.id_ls = pickle.load(open(joinpath(rcnn_feat_path, 'id_ls'), 'rb'))
        self.id2ind = dict((e, ind) for ind, e in enumerate(self.id_ls))
        self.input_dim = self.feature_mat.size(1)
        self.pname2ind = {}

    def write_log(self, fn, msg, stdout=True):
        with open(joinpath(self.output_path, fn), 'a') as f:
            f.write('%s\n' % msg)
        if stdout:
            tqdm.write(msg)

    def train_model(self, model_name, tgt_pred_ls, train_iter_gen: Callable[[], Iterator],
                  valid_iter_gen: Callable[[], Iterator],
                  test_iter_gen: Callable[[], Iterator], load_dict=None):

        if model_name == 'mlp':
            model = MLP(self.input_dim, self.config.embedding_size, len(tgt_pred_ls))
        elif model_name == 'gcn':
            model = GCN(self.input_dim, self.config.embedding_size, len(tgt_pred_ls))
        else:
            raise ValueError
        
        # used in MAML where load_dict is the global init state
        if load_dict is not None:
            model.load_state_dict(deepcopy(load_dict))

        isgcn = model_name == 'gcn'
        optimizer, scheduler, monitor = make_opt_env([model.parameters()], config=self.config)
        loss_fn = nn.CrossEntropyLoss()
        self.pname2ind = dict((e, ind) for ind, e in enumerate(tgt_pred_ls))

        num_samples = sum([True for _ in train_iter_gen()])
        num_batches = math.ceil(num_samples / self.config.batch_size)
        self.write_log('mlp_log.txt', 'num samples %i num batches %i' % (num_samples, num_batches))

        shouldstop = False
        for cur_epoch in range(self.config.num_epochs):

            if shouldstop:
                break

            epoch_iterator = self.get_batch(train_iter_gen, self.config.batch_size, isgcn)

            pbar = tqdm(total=num_batches)
            acc_loss = 0.0
            cur_batch = 0
            for batch_x, batch_y in epoch_iterator:

                if shouldstop:
                    break

                logits = model(batch_x)
                loss = loss_fn(logits, batch_y)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                scheduler.step(loss)

                pbar.update()
                acc_loss += loss.item()
                cur_batch += 1
                pbar.set_description('Epoch %i, avg loss: %.4f' % (cur_epoch, acc_loss / cur_batch))

                if (cur_batch % self.config.num_batches_per_valid == 0) or (cur_batch == num_batches):
                    tqdm.write('validating..')

                    valid_loss, r1_per_class, r1 = self.infer(model, loss_fn, valid_iter_gen, isgcn)
                    if -r1 < monitor.cur_best:
                        torch.save(model.state_dict(), joinpath(self.output_path, 'mlp_best_model'))
                    shouldstop = monitor.update(-r1)
                    self.write_log('mlp_log.txt', 'validation loss: %.4f' % valid_loss)
                    self.write_log('mlp_log.txt', '\n'.join(['valid %s R1 :%.4f' % (pn, r1_per_class[self.pname2ind[pn]])
                                         for pn in tgt_pred_ls]))
                    self.write_log('mlp_log.txt', 'valid macro R1: %.4f' % torch.mean(r1_per_class).item())
                    self.write_log('mlp_log.txt', 'valid total R1: %.4f' % r1.item())

            pbar.close()

        tqdm.write('testing..')
        model.load_state_dict(torch.load(joinpath(self.output_path, 'mlp_best_model')))

        test_loss, r1_per_class, r1 = self.infer(model, loss_fn, test_iter_gen, isgcn)
        self.write_log('mlp_log.txt', 'test loss: %.4f' % test_loss)
        self.write_log('mlp_log.txt', '\n'.join(['test %s R1 :%.4f' % (pn, r1_per_class[self.pname2ind[pn]])
                                             for pn in tgt_pred_ls]))
        self.write_log('mlp_log.txt', 'test macro R1: %.4f' % torch.mean(r1_per_class).item())
        self.write_log('mlp_log.txt', 'test total R1: %.4f' % r1.item())

        return r1

    def infer(self, model, loss_fn, iter_gen, isgcn):

        epoch_iterator = self.get_batch(iter_gen, self.config.batch_size, isgcn)
        valid_acc_loss, batch_cnt = 0, 0
        total_hits, total_y, total_pred = 0, 0, 0
        with torch.no_grad():
            for batch_x, batch_y in epoch_iterator:
                logits = model(batch_x)
                loss = loss_fn(logits, batch_y)
                valid_acc_loss += loss
                batch_cnt += 1

                y_true = F.one_hot(batch_y, num_classes=len(self.pname2ind))
                y_hat = F.one_hot(torch.argmax(logits, dim=-1), num_classes=len(self.pname2ind))

                hits = ((y_true == y_hat) * (y_true > 0)).sum(dim=0).type(torch.float32)  # (num_class)
                y_cnt = y_true.sum(dim=0).type(torch.float32)  # (num_class)
                pred = y_hat.sum(dim=0).type(torch.float32)  # (num_class)

                total_hits += hits
                total_y += y_cnt
                total_pred += pred

        r1_per_class = total_hits / (total_y + 1e-6)
        r1 = total_hits.sum() / total_y.sum()

        return valid_acc_loss / batch_cnt, r1_per_class, r1

    def get_batch(self, iter_gen, bsize, isgcn):

        x_buf, y_buf = [], []
        gcn_data = []
        for x, p_star in iter_gen():

            if isgcn:
                const, nodes, gcn_edges = x
                nodes = [self.id2ind[node] for node in nodes]
                gcn_nodes = self.feature_mat[tuple(nodes), :]
                gcn_data.append(torch_geometric.data.Data(x=gcn_nodes, edge_index=gcn_edges))
            else:
                const = x

            x_buf.append(self.id2ind[const])
            y_buf.append(self.pname2ind[p_star])

            if len(x_buf) >= bsize:
                batch_x = self.feature_mat[tuple(x_buf), :]  # (bsize, 2048)
                batch_y = torch.tensor(y_buf, device=cmd_args.device)  # (bsize, num_class)
                batch_x = [batch_x, gcn_data] if isgcn else batch_x

                yield batch_x, batch_y
                x_buf, y_buf, gcn_data = [], [], []

        if len(x_buf) > 0:
            batch_x = self.feature_mat[tuple(x_buf), :]  # (bsize, 2048)
            batch_y = torch.tensor(y_buf, device=cmd_args.device)  # (bsize, num_class)
            batch_x = [batch_x, gcn_data] if isgcn else batch_x

            yield batch_x, batch_y


def train_budegeted_gcn():
    # cmd_args.run_name = 'baseline_gcn'

    output_path, model_path = make_run_dir(cmd_args)
    model_env = ModelEnv(deepcopy(cmd_args), output_path)
    dataset = SubGraphDataset(cmd_args.data_root)
    tgt_pred_ls = [pn for pn in iterline('tgt_pred_ls.txt')]

    # NOTE hard code
    assert cmd_args.warm_up_size > 1
    budget = int(cmd_args.warm_up_size)
    model_env.write_log('budget.txt', 'budget is %i' % budget)

    def iter_sample(p2graph_dict, p_star, train=True):
        cnt = 0
        for sgraph in p2graph_dict[p_star]:

            if cnt >= budget:
                break

            if train:
                for val, consts in sgraph.fact_dict[p_star]:

                    nodes, gcn_edges = sgraph2gcn_data(sgraph, consts[0], None)
                    yield (consts[0], nodes, gcn_edges), p_star

                    cnt += 1
                    if cnt >= budget:
                        break
            else:
                for val, consts in sgraph.fact_dict[p_star]:
                    nodes, gcn_edges = sgraph2gcn_data(sgraph, consts[0], None)
                    yield (consts[0], nodes, gcn_edges), p_star

    def iter_sample2(p2graph_dict, train=True):
        for p_star in tgt_pred_ls:
            for e in iter_sample(p2graph_dict, p_star, train):
                yield e

    train_iter = lambda: iter_sample2(dataset.fact_pred2sgraph_dict, True)
    valid_iter = lambda: iter_sample2(dataset.valid_pred2sgraph_dict, True)
    test_iter = lambda: iter_sample2(dataset.test_pred2sgraph_dict, False)

    model_env.train_model('gcn', tgt_pred_ls, train_iter, valid_iter, test_iter)


def train_budgeted_mlp():

    # cmd_args.run_name = 'baseline_mlp'

    output_path, model_path = make_run_dir(cmd_args)
    model_env = ModelEnv(deepcopy(cmd_args), output_path)
    dataset = SubGraphDataset(cmd_args.data_root)
    tgt_pred_ls = [pn for pn in iterline('tgt_pred_ls.txt')]

    # NOTE hard code
    assert cmd_args.warm_up_size > 1
    budget = int(cmd_args.warm_up_size)
    model_env.write_log('budget.txt', 'budget is %i' % budget)

    def iter_sample(p2graph_dict, p_star, train=True):
        cnt = 0
        for sgraph in p2graph_dict[p_star]:

            if cnt >= budget:
                break

            if train:
                for val, consts in sgraph.fact_dict[p_star]:
                    yield consts[0], p_star
                    cnt += 1
                    if cnt >= budget:
                        break
            else:
                for val, consts in sgraph.fact_dict[p_star]:
                    yield consts[0], p_star

    def iter_sample2(p2graph_dict, train=True):
        for p_star in tgt_pred_ls:
            for e in iter_sample(p2graph_dict, p_star, train):
                yield e

    train_iter = lambda: iter_sample2(dataset.fact_pred2sgraph_dict, True)
    valid_iter = lambda: iter_sample2(dataset.valid_pred2sgraph_dict, True)
    test_iter = lambda: iter_sample2(dataset.test_pred2sgraph_dict, False)

    model_env.train_model('mlp', tgt_pred_ls, train_iter, valid_iter, test_iter)


if __name__ == '__main__':
    random.seed(cmd_args.seed)
    np.random.seed(cmd_args.seed)
    torch.manual_seed(cmd_args.seed)

    # train_budgeted_mlp()
    train_budegeted_gcn()

    # train_mlp()