import os, sys

sys.path.append('%s/..' % os.path.dirname(os.path.realpath(__file__)))

from common.cmd_args import cmd_args
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.data import Batch


class GCN(torch.nn.Module):
    def __init__(self, input_dim, latent_dim, num_class, num_hops=2):
        super(GCN, self).__init__()
        assert num_hops > 1
        self.num_hops = num_hops
        self.conv1 = GCNConv(input_dim, latent_dim).to(cmd_args.device)
        self.conv2 = GCNConv(latent_dim, latent_dim).to(cmd_args.device)

        self.fc1 = nn.Linear(input_dim + latent_dim, latent_dim).to(cmd_args.device)
        self.fc2 = nn.Linear(latent_dim, num_class).to(cmd_args.device)

    def forward(self, data):
        batch_x, gcn_data = data
        gcn_batch = Batch.from_data_list(gcn_data)
        x, edge_index = gcn_batch.x, gcn_batch.edge_index

        x = self.conv1(x, edge_index)
        x = F.relu(x)

        for _ in range(self.num_hops - 1):
            x = self.conv2(x, edge_index)
            x = F.relu(x)

        x = x[self.compute_ind(gcn_data), :] # gather the target nodes
        x = torch.cat([batch_x, x], dim=-1) # (bsize, input_dim+latent_dim)
        x = self.fc2(F.relu(self.fc1(x)))

        return x

    def compute_ind(self, gcn_data):

        buf = [0]
        cur_ind = 0
        for d in gcn_data[:-1]:
            cur_ind += d.x.size(0)
            buf.append(cur_ind)

        return tuple(buf)


def sgraph2gcn_data(sgraph, x_id, allowed_p_set):

    # NOTE make the target node always the first one
    const2ind = {x_id:0}
    nodes = [x_id]
    edges = []
    allowed = lambda x: (x in allowed_p_set) if allowed_p_set else True
    for pn in sgraph.unp_ls:
        if allowed(pn):
            for val, consts in sgraph.fact_dict[pn]:
                obj_id = consts[0]
                if obj_id != x_id:
                    nodes.append(obj_id)
                    const2ind[obj_id] = len(const2ind)

    for pn in sgraph.bip_ls[:-1]: # skip ident
        if allowed(pn):
            for val, consts in sgraph.fact_dict[pn]:
                sub, obj = consts
                edges.append([const2ind[sub], const2ind[obj]])

    gcn_edges = torch.transpose(torch.tensor(edges, dtype=torch.long).to(cmd_args.device), 0, 1)

    return nodes, gcn_edges