import os, sys

sys.path.append('%s/..' % os.path.dirname(os.path.realpath(__file__)))

from common.cmd_args import cmd_args
import torch
import torch.nn as nn
import torch.nn.functional as F
from common.utils import make_run_dir, iterline, make_opt_env
from tqdm import tqdm
from data_process.dataset import SubGraphDataset
from os.path import join as joinpath
from copy import deepcopy
import random
import numpy as np
from common.predicate import pred_register
from active_learn.mlp import ModelEnv
from common.utils import EarlyStopMonitor
from active_learn.gcn import sgraph2gcn_data


def train_maml():
    n_iters = 40000
    budget = int(cmd_args.warm_up_size)
    model_name = 'gcn'
    # cmd_args.run_name = 'maml105_' + model_name
    meta_lr = 0.1
    meta_patience = 20
    test_per_iters = 50

    output_path, model_path = make_run_dir(cmd_args)
    model_env = ModelEnv(deepcopy(cmd_args), output_path)
    dataset = SubGraphDataset(cmd_args.data_root)

    tgt_pred_ls = [pn for pn in iterline('tgt_pred_ls.txt')]

    # TODO adhoc
    allowed_unp_ls = [pn for pn in iterline('allowed_unp_ls.txt')]
    allowed_unp_ls = allowed_unp_ls + [pn for pn in iterline('../main/freq_gqa.txt') if
                                       (pn not in tgt_pred_ls and pn not in allowed_unp_ls)]
    # allowed_unp_ls = [pn for pn in pred_register.pred_dict if (pred_register.is_unp(pn) and pn not in tgt_pred_ls)]
    allowed_bip_ls = [pn for pn in pred_register.pred_dict if not pred_register.is_unp(pn)]
    allowed_p_set = set(pn for p_ls in [allowed_unp_ls, allowed_bip_ls] for pn in p_ls)

    model_env.write_log('budget.txt', 'budget is %i' % budget)

    def iter_sample(p2graph_dict, p_star, train=True):
        cnt = 0
        for sgraph in p2graph_dict[p_star]:

            if cnt >= budget:
                break

            if train:
                for val, consts in sgraph.fact_dict[p_star]:
                    if model_name == 'mlp':
                        yield consts[0], p_star
                    else:
                        nodes, gcn_edges = sgraph2gcn_data(sgraph, consts[0], None)
                        yield (consts[0], nodes, gcn_edges), p_star

                    cnt += 1
                    if cnt >= budget:
                        break
            else:
                for val, consts in sgraph.fact_dict[p_star]:
                    if model_name == 'mlp':
                        yield consts[0], p_star
                    else:
                        nodes, gcn_edges = sgraph2gcn_data(sgraph, consts[0], None)
                        yield (consts[0], nodes, gcn_edges), p_star

    def iter_sample2(p2graph_dict, p_ls, train=True):
        for p_star in p_ls:
            for e in iter_sample(p2graph_dict, p_star, train):
                yield e

    nways = len(tgt_pred_ls)
    def next_task():
        while True:
            p_ls = deepcopy(allowed_unp_ls)
            random.shuffle(p_ls)
            yield p_ls[:nways]

    # mlp_tgt_ls = allowed_unp_ls + tgt_pred_ls
    load_dict = None
    bak = model_env.config.num_epochs
    monitor = EarlyStopMonitor(meta_patience)
    shouldstop = False
    for meta_iter, p_ls in enumerate(next_task()):
        model_env.config.num_epochs = 1  # NOTE inner training for one epoch only

        if (meta_iter >= n_iters) or shouldstop:
            break

        train_iter = lambda: iter_sample2(dataset.fact_pred2sgraph_dict, p_ls, True)
        valid_iter = lambda: iter_sample2(dataset.valid_pred2sgraph_dict, p_ls, True)
        test_iter = lambda: iter_sample2(dataset.test_pred2sgraph_dict, p_ls, False)

        model_env.train_model(model_name, p_ls, train_iter, valid_iter, test_iter, load_dict=load_dict)

        task_load_dict = torch.load(joinpath(model_env.output_path, 'mlp_best_model'))
        if load_dict is None:
            load_dict = task_load_dict
        else:
            sch_meta_lr = meta_lr * (1 - meta_iter / n_iters)
            load_dict = {name: load_dict[name] + sch_meta_lr * (task_load_dict[name] - load_dict[name])
                         for name in load_dict}

        if meta_iter % test_per_iters == 0:

            # budgeted training
            model_env.config.num_epochs = bak
            train_iter = lambda: iter_sample2(dataset.fact_pred2sgraph_dict, tgt_pred_ls, True)
            valid_iter = lambda: iter_sample2(dataset.valid_pred2sgraph_dict, tgt_pred_ls, True)
            test_iter = lambda: iter_sample2(dataset.test_pred2sgraph_dict, tgt_pred_ls, False)

            r1 = model_env.train_model(model_name, tgt_pred_ls, train_iter, valid_iter, test_iter, load_dict=load_dict)
            model_env.write_log('maml_log.txt', 'Meta iter %i test total R1: %.4f' % (meta_iter, r1.item()))

            if -r1 < monitor.cur_best:
                torch.save(load_dict, joinpath(model_env.output_path, 'maml_best_global_model'))
            shouldstop = monitor.update(-r1)


if __name__ == '__main__':
    random.seed(cmd_args.seed)
    np.random.seed(cmd_args.seed)
    torch.manual_seed(cmd_args.seed)

    train_maml()
