cd active_learn

python main.py -run_name al25_mlp_b5 -warm_up_size 25 -budget 5 -fill_budget -learner mlp
