import os, sys

sys.path.append('%s/..' % os.path.dirname(os.path.realpath(__file__)))

from common.cmd_args import cmd_args
from data_process.dataset import Dataset
import torch
import torch.nn
import torch.nn.functional as F
import numpy as np
import random
from tqdm import tqdm
import torch.optim as optim
from itertools import chain
from common.utils import makedir, get_output_folder, EarlyStopMonitor
from os.path import join as joinpath
from common.predicate import pred_register
from model.Models import RuleLearner, PhiList, TabularPhiList
from model.gqa_freq import GQAFreq
import common.phi as phi
from data_process.dataset import SubGraphDataset
from data_process.dataset import gen_neg_samples
from common import constants
from common.utils import iterline
import math
import time
import sys


def tensorlog_dataset(root_path):
    name_ls = ['family', 'fb15k-237', 'wn18']
    return any(n in root_path for n in name_ls)


def init_model():
    unp_ls = [(pn, phi.TabularPhi(pn)) for pn in pred_register.pred_dict if pred_register.is_unp(pn)]
    bip_ls = [(pn, phi.TabularPhi(pn)) for pn in pred_register.pred_dict if not pred_register.is_unp(pn)]

    phi_list = TabularPhiList(unp_ls, bip_ls).to(cmd_args.device)
    rule_learner = RuleLearner(pred_register.num_pred, phi_list).to(cmd_args.device)

    return rule_learner


def prep_dataset():
    dataset = SubGraphDataset(cmd_args.data_root)
    bg_sgraph = None
    fbd = None

    if tensorlog_dataset(cmd_args.data_root):
        # fact_sgraph

        # sample negative samples for tensorlog dataset, e.g. FB15K
        fact_sgraph = list(dataset.fact_pred2sgraph_dict.values())[0][0]
        test_sgraph = list(dataset.test_pred2sgraph_dict.values())[0][0]
        valid_sgraph = list(dataset.valid_pred2sgraph_dict.values())[0][0]

        # TODO debug
        # num_batch_ls = [dataset.get_numBatches(dataset.fact_pred2sgraph_dict, pn, cmd_args.batch_size)
        #                 for pn in fact_sgraph.bip_ls[:-1]]
        # tmp = sorted(enumerate(num_batch_ls), key=lambda x: x[1], reverse=True)
        # for e in tmp:
        #     print(e[1], fact_sgraph.bip_ls[e[0]])
        # tmp = [e for e in tmp if e[1] > 50]
        # fact_sgraph.bip_ls = [fact_sgraph.bip_ls[e[0]] for e in tmp] + [fact_sgraph.bip_ls[-1]]
        # tgt_pred_ls = fact_sgraph.bip_ls[:-1]
        # test_sgraph.bip_ls = fact_sgraph.bip_ls
        # valid_sgraph.bip_ls = fact_sgraph.bip_ls

        fact_unp, fact_bip = fact_sgraph.toArray(update=False, keep_array=True)
        valid_unp, valid_bip = valid_sgraph.toArray(update=False, keep_array=True)
        test_unp, test_bip = test_sgraph.toArray(update=False, keep_array=True)

        global_unp = fact_unp + valid_unp + test_unp
        global_bip = fact_bip + valid_bip + test_bip

        # TODO debug
        # tgt_pred_ls = ['_has_part']  # tensorlog dataset only contains bip, excluding Ident
        tgt_pred_ls = test_sgraph.bip_ls[:-1]  # tensorlog dataset only contains bip, excluding Ident
        # tqdm.write('sample %s sgraph negative samples..' % cmd_args.data_root)
        # gen_neg_samples(fact_sgraph, [], tgt_pred_ls,
        #                 cmd_args.neg_sample_ratio, global_unp, global_bip)

        bg_sgraph = fact_sgraph
        if 'fb15k' in cmd_args.data_root:
            fbd = FBSubGraph(10)

    elif 'gqa' in cmd_args.data_root:

        tgt_pred_ls = ['window', 'person', 'shirt', 'tree',
                       'wall', 'building', 'ground', 'sky',
                       'sign', 'head', 'pole', 'hand',
                       'grass', 'hair', 'leg', 'car',
                       'leaf', 'table', 'ear', 'pants']

        # TODO debug
        tgt_pred_ls = [line for line in iterline('freq_gqa.txt')]

        # tgt_pred_ls = set([k for k, v in dataset.valid_pred2sgraph_dict.items() if len(v) > 0])
        # tgt_pred_ls.update([k for k, v in dataset.test_pred2sgraph_dict.items() if len(v) > 0])
        # tgt_pred_ls = [pn for pn in tgt_pred_ls if pred_register.is_unp(pn)]  # only use unp as tgt in gqa

        # # TODO debug
        # # sample negative samples for gqa dataset
        # tqdm.write('sample gqa negative samples..')
        # for sgraph_ls in tqdm(dataset.fact_pred2sgraph_dict.values()):
        #     for sgraph in sgraph_ls:
        #         if not sgraph.has_neg_sample:
        #             gen_neg_samples(sgraph, tgt_pred_ls, [], cmd_args.neg_sample_ratio)

        # # TODO debug
        # gqa_freq = GQAFreq('../data_process/gqa_ht_dict', '../data_process/gqa_th_dict')
        # gqa_freq.predict(dataset.test_pred2sgraph_dict, tgt_pred_ls)
        # sys.exit(0)

    elif 'evensucc' in cmd_args.data_root:
        tqdm.write('running even-odd..')
        tgt_pred_ls = ['even']

    else:
        raise ValueError

    return dataset, tgt_pred_ls, bg_sgraph, fbd


def train():
    # make run folder
    output_path = get_output_folder(cmd_args.output_root, run_name=cmd_args.run_name)
    makedir(output_path, remove_old=False)
    model_path = joinpath(output_path, 'best_model')
    makedir(model_path, remove_old=False)
    with open(joinpath(output_path, 'run_log.txt'), 'w') as f:
        for arg in vars(cmd_args):
            f.write('%s %s\n' % (str(arg), str(getattr(cmd_args, arg))))

    # prep dataset
    dataset, tgt_pred_ls, bg_sgraph, fbd = prep_dataset()

    skip_prob_dict = dict((pn, 0) for pn in tgt_pred_ls)

    # init models
    model_dict = dict([(pn, init_model()) for pn in tgt_pred_ls])
    opt_dict = {}
    for pn in tgt_pred_ls:
        model = model_dict[pn]
        params = [model.parameters()]
        optimizer = optim.Adam(chain.from_iterable(params),
                               lr=cmd_args.learning_rate, weight_decay=cmd_args.l2_coef)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min',
                                                         factor=cmd_args.lr_decay_factor,
                                                         patience=cmd_args.lr_decay_patience,
                                                         min_lr=cmd_args.lr_decay_min)
        opt_dict[pn] = [optimizer, scheduler]

    if cmd_args.model_load_path:
        tqdm.write('Load model from %s' % cmd_args.model_load_path)
        for pn, model in model_dict.items():
            model.load_state_dict(torch.load(joinpath(cmd_args.model_load_path, str(pred_register.pred2ind[pn]))))

    monitor = EarlyStopMonitor(cmd_args.patience)

    if cmd_args.hard_sample:
        tqdm.write('Doing hard sample')
    else:
        cmd_args.num_samples = 1
        tqdm.write('Doing averaging')

    shouldstop = False
    st = time.time()
    total_batch = 0
    for cur_epoch in range(cmd_args.num_epochs):

        if shouldstop:
            break

        num_batches, epoch_iterator = dataset.sample(dataset.fact_pred2sgraph_dict,
                                                     cmd_args.batch_size,
                                                     allow_recursion=cmd_args.allow_recursion,
                                                     rotate=cmd_args.rotate,
                                                     keep_array=cmd_args.kb,
                                                     tgt_pred_ls=tgt_pred_ls,
                                                     bg_sgraph=None)

        pbar = tqdm(total=num_batches)
        acc_loss = 0.0
        cur_batch = 0
        for input_x, input_y, unp_ls, bip_ls, p_star, _ in epoch_iterator:

            if shouldstop:
                break

            skip = False
            if cmd_args.skip_trained and ((skip_prob_dict[p_star] > 0.5) and
                                          (random.random() < skip_prob_dict[p_star])):
                skip = True

            if 'fb15k' in cmd_args.data_root:
                bip_ls, input_x = fbd.filter(bip_ls, input_x, p_star)
            if bip_ls is None:
                skip = True

            if not skip:
                # [num_sample] loss
                sample_val_ls, mask_ls, name_ls = model_dict[p_star](input_x, input_y, pred_register.pred2ind[p_star],
                                                                     unp_ls, bip_ls, cmd_args.gumbelmax_temp,
                                                                     cmd_args.num_samples)

                tqdm.write('%s <- %s' % (p_star, name_ls[0][-1][-1][0]))

                cand_val = torch.cat([val_ls[-1] for val_ls in sample_val_ls], dim=-1)
                input_y = input_y.to(cmd_args.device)

                num_cand = cand_val.size(-1)
                succ_loss = F.binary_cross_entropy(cand_val.clamp(max=1), input_y.view(-1, 1).expand(-1, num_cand))

                loss = succ_loss

                optimizer, scheduler = opt_dict[p_star]
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                scheduler.step(succ_loss)

            pbar.update()
            acc_loss += (acc_loss / (cur_batch + 1e-6)) if skip else loss.item()
            cur_batch += 1
            total_batch += 1
            pbar.set_description('Epoch %i, avg loss: %.4f' % (cur_epoch, acc_loss / cur_batch))

            if total_batch % cmd_args.num_batches_per_valid == 0:

                tqdm.write('validating..')
                with torch.no_grad():
                    rule_ls, global_prf, global_f = inference(model_dict, dataset,
                                                              dataset.test_pred2sgraph_dict,
                                                              tgt_pred_ls, bg_sgraph, fbd, skip_prob_dict)

                update_rule = -global_f < monitor.cur_best
                shouldstop = monitor.update(-global_f)
                if update_rule:
                    best_rule_ls = rule_ls
                    for pn, model in model_dict.items():
                        torch.save(model.state_dict(), joinpath(model_path, str(pred_register.pred2ind[pn])))
                    with open(joinpath(output_path, 'best_rule.txt'), 'w') as f:
                        f.write('Epoch %i batch %i time %.4f %s\n' %
                                (cur_epoch, cur_batch, time.time() - st, global_prf))
                        for rule_str in best_rule_ls:
                            f.write('%s\n' % rule_str)

        pbar.close()

    tqdm.write('testing..')
    with torch.no_grad():
        for pn, model in model_dict.items():
            model.load_state_dict(torch.load(joinpath(model_path, str(pred_register.pred2ind[pn]))))
        _, global_prf, global_f = inference(model_dict, dataset, dataset.test_pred2sgraph_dict,
                                            tgt_pred_ls, bg_sgraph, fbd, skip_prob_dict)
        with open(joinpath(output_path, 'test_loss.txt'), 'w') as f:
            f.write('%s\n' % (global_prf))

        if cmd_args.kb:
            tqdm.write('evaluating mrr and hits..')
            mh_dict = mrr_and_hits(model_dict, dataset, dataset.test_pred2sgraph_dict, tgt_pred_ls, bg_sgraph, fbd)
            with open(joinpath(output_path, 'test_mh.txt'), 'w') as f:
                for pn, mh in mh_dict.items():
                    mh_str = 'mrr %.4f hits@10 %.4f %s' % (mh[0], mh[1], pn)
                    tqdm.write(mh_str)
                    f.write('%s\n' % mh_str)
                mrr = sum(e[0] for e in mh_dict.values()) / len(mh_dict)
                hits = sum(e[1] for e in mh_dict.values()) / len(mh_dict)
                mh_str = 'global mrr %.4f hits@10 %.4f' % (mrr, hits)
                tqdm.write(mh_str)
                f.write('%s\n' % mh_str)


class FBSubGraph:

    def __init__(self, filter_under):
        self.filter_under = filter_under
        pstar_sgraph_dict = {}
        pn_freq_dict = {}

        for line in iterline(joinpath(cmd_args.data_root, 'train_cnt.txt')):
            parts = line.split(' ')
            cnt, pn = int(parts[0]), parts[1]
            pn_freq_dict[pn] = cnt

        for line in iterline(joinpath(cmd_args.data_root, 'rules_by_q')):
            parts = line.split(' ')
            pstar_sgraph_dict[parts[0]] = set(parts[1:])

        self.pstar_sgraph_dict = pstar_sgraph_dict
        self.pn_freq_dict = pn_freq_dict

    def filter(self, bip_ls, input_x, p_star, evaluate=False):
        pstar_d = p_star.split('/')[1]
        d_set = self.pstar_sgraph_dict[pstar_d]
        if cmd_args.allow_recursion:
            try:
                pstar_ind = bip_ls.index(p_star)
            except:
                pstar_ind = None
        else:
            pstar_ind = None
        # filter_ind_ls = [ind for ind, pn in enumerate(bip_ls) if ((ind == pstar_ind) or
        #                                                           ((pn in self.freq_set) and
        #                                                            (pn.split('/')[1] in d_set)))]

        filter_ind_ls = sorted([(ind, self.pn_freq_dict[pn]) for ind, pn in
                                enumerate(bip_ls[:-1]) if pn.split('/')[1] in d_set],
                               key=lambda x: x[1], reverse=True)[:self.filter_under]
        filter_ind_ls = [e[0] for e in filter_ind_ls]

        if (len(filter_ind_ls) == 1) and (filter_ind_ls[0] == pstar_ind):
            filter_ind_ls = []

        if evaluate:
            if len(filter_ind_ls) == 0:
                filter_ind_ls = [3]

        if len(filter_ind_ls) == 0:
            return None, None

        input_x[0][1] = [input_x[0][1][i] for i in filter_ind_ls] + [input_x[0][1][-1]]
        return [bip_ls[i] for i in filter_ind_ls] + [bip_ls[-1]], input_x


def inference(model_dict, dataset, sgraph_dict, tgt_pred_ls, bg_sgraph, fbd, skip_prob_dict):
    # get one hard sample to get the learned formulas
    infer_temp, infer_numSample = 0.001, 1
    bak1, bak2, bak3 = cmd_args.hard_sample, cmd_args.attn_temp, cmd_args.sample_neg
    if not cmd_args.kb:
        cmd_args.hard_sample = True
    cmd_args.attn_temp = infer_temp
    cmd_args.sample_neg = False

    acc_loss = 0.0
    cur_batch = 0
    rule_ls = []
    g_pred_cnt, g_inter_cnt, g_y_cnt = 0, 0, 0
    rule_dict = dict()
    for tgt_p in tgt_pred_ls:
        # rotate over data w.r.t each p_star
        num_batches, epoch_iterator = dataset.sample(sgraph_dict,
                                                     cmd_args.batch_size,
                                                     allow_recursion=cmd_args.allow_recursion,
                                                     rotate=False,
                                                     keep_array=cmd_args.kb,
                                                     tgt_pred_ls=[tgt_p],
                                                     bg_sgraph=bg_sgraph)

        name_ls = None
        apply_cnt, pred_cnt, inter_cnt, y_cnt = None, None, None, None
        joint_pred_cnt, joint_inter_cnt = 0, 0
        for input_x, input_y, unp_ls, bip_ls, p_star, _ in epoch_iterator:

            # # TODO debug
            # input_x[0][1] = input_x[0][1][10:]
            # bip_ls = bip_ls[10:]
            if 'fb15k' in cmd_args.data_root:
                bip_ls, input_x = fbd.filter(bip_ls, input_x, p_star, evaluate=True)
            assert bip_ls is not None

            # [num_sample] loss

            sample_val_ls, mask_ls, name_ls = model_dict[p_star](input_x, input_y, pred_register.pred2ind[p_star],
                                                                 unp_ls, bip_ls,
                                                                 infer_temp, infer_numSample)

            # # TODO debug
            # if p_star not in rule_dict:
            #     rule_dict[p_star] = set()
            # rule_dict[p_star].add('%s <- %s' % (p_star, name_ls[0][-1][-1][0]))

            # tqdm.write('%s <- %s' % (p_star, name_ls[0][-1][-1][0]))

            cand_val = torch.cat([val_ls[-1] for val_ls in sample_val_ls], dim=-1)
            # cand_mask = torch.cat(mask_ls, dim=-1)
            num_cand = cand_val.size(-1)
            input_y = input_y.to(cmd_args.device).view(-1, 1).expand(-1, num_cand)

            # TODO debug
            # succ_loss = F.binary_cross_entropy(cand_val, input_y)#, weight=cand_mask)
            # fail_loss = F.binary_cross_entropy(cand_val, input_y, weight=1 - cand_mask)
            # loss = succ_loss #+ cmd_args.recall_penalty * fail_loss

            prediction = (cand_val >= 0.5).type(torch.float)  # (cand_val * cand_mask >= 0.5).type(torch.float)
            intersect = ((prediction > 0) * (input_y > 0)).type(torch.float)
            if apply_cnt is None:
                apply_cnt = input_y.sum(dim=0)  # cand_mask.sum(dim=0)
                pred_cnt = prediction.sum(dim=0)
                inter_cnt = intersect.sum(dim=0)
                y_cnt = input_y.sum(dim=0)
                joint_pred_cnt = (prediction.max(dim=-1)[0]).sum()
                joint_inter_cnt = (intersect.max(dim=-1)[0]).sum()
            else:
                apply_cnt += input_y.sum(dim=0)  # cand_mask.sum(dim=0)
                pred_cnt += prediction.sum(dim=0)
                inter_cnt += intersect.sum(dim=0)
                y_cnt += input_y.sum(dim=0)
                joint_pred_cnt += (prediction.max(dim=-1)[0]).sum()
                joint_inter_cnt += (intersect.max(dim=-1)[0]).sum()

            # acc_loss += loss
            cur_batch += 1

        y_cnt += 1e-8  # prevent div by 0
        pred_cnt += 1e-8
        joint_pred_cnt += 1e-8

        p, r = inter_cnt / pred_cnt, inter_cnt / y_cnt
        f = 2 * p * r / (p + r + 1e-8)

        joint_p, joint_r = joint_inter_cnt / joint_pred_cnt, joint_inter_cnt / y_cnt[0]
        joint_f = 2 * joint_p * joint_r / (joint_p + joint_r + 1e-8)

        g_pred_cnt += joint_pred_cnt
        g_inter_cnt += joint_inter_cnt
        g_y_cnt += y_cnt[0]

        tgt_joint_str = 'tgt pred joint p %.4f r %.4f f %.4f' % (joint_p.item(), joint_r.item(), joint_f.item())
        tqdm.write(tgt_joint_str)
        rule_ls.append(tgt_joint_str)
        for ind, cand in enumerate(name_ls[0][-1][-1]):
            tgt_p_rule = 'cnt %.4f p %.4f r %.4f f %.4f\t: %s <- %s' % (apply_cnt[ind].item(),
                                                                        p[ind].item(),
                                                                        r[ind].item(),
                                                                        f[ind].item(), tgt_p, cand)
            tqdm.write(tgt_p_rule)
            rule_ls.append(tgt_p_rule)

        if skip_prob_dict[tgt_p] < joint_f.item():
            skip_prob_dict[tgt_p] = joint_f.item()

    # # TODO debug
    # with open('rule_ls.txt', 'w') as f:
    #     for p_star in rule_dict:
    #         for r in rule_dict[p_star]:
    #             f.write('%s\n' % r)

    global_p, global_r = g_inter_cnt / g_pred_cnt, g_inter_cnt / g_y_cnt
    global_f = 2 * global_p * global_r / (global_p + global_r + 1e-8)

    global_prf = 'global p %.4f r %.4f f %.4f' % (global_p.item(), global_r.item(), global_f.item())
    tqdm.write(global_prf)
    # tqdm.write('loss %.4f' % (acc_loss / cur_batch).item())
    cmd_args.hard_sample, cmd_args.attn_temp, cmd_args.sample_neg = bak1, bak2, bak3
    return rule_ls, global_prf, global_f


def dump_all_rules(run_log_path):
    assert os.path.isdir(run_log_path)
    model_path = joinpath(run_log_path, 'best_model')
    assert os.path.isdir(model_path)
    import pickle

    # get one hard sample to get the learned formulas
    infer_numSample = 1
    if not cmd_args.kb:
        cmd_args.hard_sample = True
    cmd_args.sample_neg = False

    dataset, tgt_pred_ls, bg_sgraph, fbd = prep_dataset()
    model_dict = dict([(pn, init_model()) for pn in tgt_pred_ls])

    with torch.no_grad():
        for pn, model in model_dict.items():
            model.load_state_dict(torch.load(joinpath(model_path, str(pred_register.pred2ind[pn]))))

        for tgt_p in tgt_pred_ls:
            rule_ls = []
            # rotate over data w.r.t each p_star
            num_batches, epoch_iterator = dataset.sample(dataset.fact_pred2sgraph_dict,
                                                         cmd_args.batch_size,
                                                         allow_recursion=cmd_args.allow_recursion,
                                                         rotate=False,
                                                         keep_array=cmd_args.kb,
                                                         tgt_pred_ls=[tgt_p],
                                                         bg_sgraph=bg_sgraph)

            pbar = tqdm(total=num_batches)
            for input_x, input_y, unp_ls, bip_ls, p_star, sgraph_name in epoch_iterator:
                assert bip_ls is not None

                sample_val_ls, mask_ls, name_ls = model_dict[p_star](input_x, input_y, pred_register.pred2ind[p_star],
                                                                     unp_ls, bip_ls,
                                                                     None, infer_numSample)

                cand_val = torch.cat([val_ls[-1] for val_ls in sample_val_ls], dim=-1)
                num_cand = cand_val.size(-1)
                input_y = input_y.to(cmd_args.device).view(-1, 1).expand(-1, num_cand)
                prediction = (cand_val >= 0.5).type(torch.float)
                intersect = ((prediction > 0) * (input_y > 0)).type(torch.float)

                rule_ls.append([p_star, name_ls[0][-1][-1][0], intersect.sum().item(), sgraph_name, unp_ls, bip_ls])
                pbar.update()
                pbar.set_description(tgt_p)

            pbar.close()
            pickle.dump(rule_ls, open('dumps/%s_rule_ls' % tgt_p, 'wb'))


def kb_test(run_log_path):
    assert os.path.isdir(run_log_path)
    model_path = joinpath(run_log_path, 'best_model')
    assert os.path.isdir(model_path)

    dataset, tgt_pred_ls, bg_sgraph, fbd = prep_dataset()
    model_dict = dict([(pn, init_model()) for pn in tgt_pred_ls])
    with torch.no_grad():
        for pn, model in model_dict.items():
            model.load_state_dict(torch.load(joinpath(model_path, str(pred_register.pred2ind[pn]))))
        mh_dict = mrr_and_hits(model_dict, dataset, dataset.test_pred2sgraph_dict, tgt_pred_ls, bg_sgraph, fbd)

    with open(joinpath(run_log_path, 'test_mh.txt'), 'w') as f:
        for pn, mh in mh_dict.items():
            mh_str = 'mrr %.4f hits@10 %.4f cnt %i %s' % (mh[0], mh[1], int(mh[2]), pn)
            tqdm.write(mh_str)
            f.write('%s\n' % mh_str)
        wsum = sum(float(e[2]) for e in mh_dict.values())
        mrr = sum(e[0] * e[2] / wsum for e in mh_dict.values())
        hits = sum(e[1] * e[2] / wsum for e in mh_dict.values())
        mh_str = 'global mrr %.4f hits@10 %.4f' % (mrr, hits)
        tqdm.write(mh_str)
        f.write('%s\n' % mh_str)


def mrr_and_hits(model_dict, dataset, sgraph_dict, tgt_pred_ls, bg_sgraph, fbd):
    # get one hard sample to get the learned formulas
    infer_temp, infer_numSample = 0.001, 1
    num_const = len(bg_sgraph.const2ind_dict)
    n_eval = 20

    def const_iter(nc, nb, is_unp):
        cnt = 0
        l = []
        for i in range(nc):
            k = [i] if is_unp else range(nc)
            for j in k:
                l.append((i, j))
                cnt += 1
                if cnt == nb:
                    yield l
                    l = []
                    cnt = 0

    def rand_iter(nc, nb, is_unp):
        num_eval = n_eval
        cnt, t_cnt = 0, 0
        l = []
        while t_cnt < num_eval:
            i = random.randint(0, nc - 1)
            j = i if is_unp else random.randint(0, nc - 1)
            l.append((i, j))
            cnt += 1
            if cnt == nb:
                yield l
                l = []
                cnt = 0
                t_cnt += 1
        if len(l) > 0:
            yield l

    mh_dict = {}
    for tgt_p in tgt_pred_ls:
        # rotate over data w.r.t each p_star
        num_batches, epoch_iterator = dataset.sample(sgraph_dict,
                                                     cmd_args.batch_size,
                                                     allow_recursion=cmd_args.allow_recursion,
                                                     rotate=False,
                                                     keep_array=cmd_args.kb,
                                                     tgt_pred_ls=[tgt_p],
                                                     bg_sgraph=bg_sgraph)

        cand_val_ls = []
        pstar_bip_ls, pstar_unp_ls, pstar_unp_arr_ls, pstar_bip_arr_ls = [], [], [], []
        for input_x, input_y, unp_ls, bip_ls, p_star, _ in epoch_iterator:

            # # TODO debug
            # input_x[0][1] = input_x[0][1][10:]
            # bip_ls = bip_ls[10:]
            if 'fb15k' in cmd_args.data_root:
                bip_ls, input_x = fbd.filter(bip_ls, input_x, p_star, evaluate=True)
            assert bip_ls is not None

            sample_val_ls, mask_ls, name_ls = model_dict[p_star](input_x, input_y, pred_register.pred2ind[p_star],
                                                                 unp_ls, bip_ls, infer_temp, infer_numSample)

            cand_val = torch.cat([val_ls[-1] for val_ls in sample_val_ls], dim=-1)
            cand_val_ls.append(cand_val)
            pstar_bip_ls = bip_ls
            pstar_unp_ls = unp_ls
            pstar_unp_arr_ls = input_x[0][0]
            pstar_bip_arr_ls = input_x[0][1]

        cand_val = torch.cat(cand_val_ls, dim=0)
        is_unp = pred_register.is_unp(tgt_p)
        full_batch_size = 100
        c_iter = rand_iter(num_const, full_batch_size, is_unp) if cmd_args.rand_eval else \
            const_iter(num_const, full_batch_size, is_unp)
        num_full_batches = math.ceil(num_const * (1 if is_unp else num_const) / full_batch_size)
        num_full_batches = n_eval if cmd_args.rand_eval else num_full_batches
        query_rank = torch.zeros_like(cand_val).squeeze(-1)
        p_bar = tqdm(total=num_full_batches)
        p_bar.set_description(tgt_p)
        for ind_ls in c_iter:
            ind_arr = torch.tensor(ind_ls, dtype=torch.int64, device=cmd_args.device)  # (b,2)
            if is_unp:
                ind_arr = ind_arr[:, 0].unsqueeze(1)  # (b,1)
            arg_input = F.one_hot(ind_arr, num_classes=num_const)  # (b,num_arg,num_const)
            arg_input = arg_input.type(torch.float32)
            input_x = [[pstar_unp_arr_ls, pstar_bip_arr_ls], arg_input]
            sample_val_ls, _, _ = model_dict[tgt_p](input_x, None, pred_register.pred2ind[tgt_p],
                                                    pstar_unp_ls, pstar_bip_ls,
                                                    infer_temp, infer_numSample)
            p_bar.update()
            p_val = sample_val_ls[-1][-1]
            query_rank += (cand_val <= p_val.transpose(0, 1)).sum(dim=-1).type(torch.float32)  # worst rank

        query_rank -= (cand_val <= cand_val.transpose(0, 1)).sum(dim=-1).type(torch.float32)
        query_rank = query_rank.clamp(min=0)
        query_rank += 1
        mrr = (1 / query_rank).mean().item()
        hits = ((query_rank <= 10).sum().type(torch.float32) / query_rank.size(0)).item()
        mh_dict[tgt_p] = [mrr, hits, query_rank.size(0)]
        tqdm.write('mrr %.4f hits@10 %.4f cnt %i %s' % (mrr, hits, query_rank.size(0), tgt_p))
        p_bar.close()

    return mh_dict


if __name__ == '__main__':
    random.seed(cmd_args.seed)
    np.random.seed(cmd_args.seed)
    torch.manual_seed(cmd_args.seed)

    # dataset, tgt_pred_ls, bg_sgraph = prep_dataset()
    # tgt_pred_ls = ['_has_part']
    #
    # factd = dataset.fact_pred2sgraph_dict['_has_part'][0]
    # validd = dataset.test_pred2sgraph_dict['_has_part'][0]
    # po_ind = validd.bip_ls.index('_part_of')
    # hp_ind = validd.bip_ls.index('_has_part')
    # ttt = factd.bip_arr_ls[po_ind].transpose(0, 1) * validd.bip_arr_ls[hp_ind]
    # ttt = ttt.mm(torch.ones(ttt.size(0), 1, device=cmd_args.device))
    # ttt = ttt.transpose(0,1).mm(torch.ones(ttt.size(0), 1, device=cmd_args.device))
    #
    # for tgt_p in tgt_pred_ls:
    #
    #     # rotate over data w.r.t each p_star
    #     num_batches, epoch_iterator = dataset.sample(dataset.test_pred2sgraph_dict,
    #                                                  cmd_args.batch_size,
    #                                                  allow_recursion=cmd_args.allow_recursion,
    #                                                  rotate=False,
    #                                                  keep_array=True,
    #                                                  tgt_pred_ls=[tgt_p],
    #                                                  bg_sgraph=bg_sgraph)
    #
    #     name_ls = None
    #     apply_cnt, pred_cnt, inter_cnt, y_cnt = None, None, None, None
    #     joint_pred_cnt, joint_inter_cnt = 0, 0
    #     tt = 0
    #     for input_x, input_y, unp_ls, bip_ls, p_star in epoch_iterator:
    #         # TODO debug
    #         input_x[0][1] = input_x[0][1][10:]
    #         bip_ls = bip_ls[10:]
    #
    #         noarg_input, arg_input = input_x
    #
    #         unp_arr_ls, bip_arr_ls = noarg_input
    #
    #         t1 = bip_arr_ls[1].transpose(0, 1).mm(arg_input[:, 1, :].transpose(0, 1)).transpose(0, 1)
    #         t1 = t1 * arg_input[:, 0, :]
    #         t2 = t1.sum(dim=-1)
    #         tt += t2.sum()
    #
    #     print(tt)
    # inds = torch.LongTensor([[0,1,2],[0,1,2]])
    # vals = torch.FloatTensor([1,2,3])
    # sizes = [10000, 10000]
    # mat = torch.sparse_coo_tensor(inds, vals, sizes, device=cmd_args.device)
    #
    # # mat = torch.zeros(10000, 10000).to(cmd_args.device)
    # # mat[0, 0] = 1
    # # mat[1, 1] = 2
    # # mat[2, 2] = 3
    # x = torch.ones(32, 10000, 1, requires_grad=True).to(cmd_args.device)
    #
    # tmp = x
    # for _ in range(2000):
    #     bsize, num_const = tmp.size(0), tmp.size(1)
    #     tmp = tmp.transpose(0, 1).view(num_const, -1)
    #     tmp = mat.mm(tmp)
    #     tmp = tmp.view(num_const, bsize, -1).transpose(0, 1)
    #
    # tmp.sum().backward()
    # f1 = x.grad

    # x = torch.randn(3, requires_grad=True)

    # x = torch.rand(7, 12).to(cmd_args.device)
    # y = torch.ones(7).to(cmd_args.device)
    #
    # import time
    # st = time.time()
    # for _ in range(30):
    #     succ_loss = F.binary_cross_entropy(x, y.view(-1, 1).expand(-1, 12))
    # print(time.time() - st)

    # a = torch.ones(1, 3000, 3000).to(cmd_args.device)
    # x = torch.ones(3, 3000, 100, device=cmd_args.device, requires_grad=True)
    # constmm = ConstMatMul.apply
    #
    #
    # import time
    # st = time.time()
    # tmp = x
    # # with torch.no_grad():
    # for _ in range(50):
    #     # tmp = a.matmul(tmp)
    #     tmp = constmm(a, tmp)
    #     tmp += 1
    # tmp.sum().backward()
    # g1 = x.grad
    # print(time.time() - st)
    #
    #
    # st = time.time()
    # tmp = x
    # # with torch.no_grad():
    # for _ in range(50):
    #     tmp = a.matmul(tmp)
    #     tmp += 1
    #     # tmp = constmm(a, tmp)
    # tmp = tmp.sum().backward()
    # g2 = x.grad
    # print(time.time() - st)
    #
    # print(torch.all(g1 == g2))

    dump_all_rules('../run_logs/gqa_150_conted-run1')
    sys.exit(0)

    # train()
    if cmd_args.test_only:
        kb_test(cmd_args.output_root)
    else:
        train()
