import torch
import torch.nn as nn
import numpy as np


class ScaledDotProductAttention(nn.Module):
    ''' Scaled Dot-Product Attention '''

    def __init__(self, temperature, attn_dropout=0.1):
        super().__init__()
        self.temperature = temperature
        self.dropout = nn.Dropout(attn_dropout)
        self.softmax = nn.Softmax(dim=2)

    def forward(self, q, k, v, mask=None):

        attn = torch.bmm(q, k.transpose(1, 2))
        attn = attn / self.temperature

        if mask is not None:
            attn = attn.masked_fill(mask, -np.inf)
        sfm_attn = self.softmax(attn)

        # if mask is not None:
        #     sfm_attn = attn.exp() * mask
        #     sfm_attn = sfm_attn / sfm_attn.sum(dim=-1, keepdim=True)
        # else:
        #     sfm_attn = self.softmax(attn)

        # NOTE attn = self.dropout(attn)

        output = torch.bmm(sfm_attn, v)

        return output, sfm_attn, attn
