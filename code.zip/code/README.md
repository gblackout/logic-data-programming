### Requirements
- python 3.6+
- pytorch 1.1.0+
- torch-geometric
- numpy
- tqdm

### Active learning on Visual Genome

First, download the scene-graph dataset from the official site (click "Download Scene Graphs")

    https://cs.stanford.edu/people/dorarad/gqa/download.html

Extract the files, and run the following script to generate the dataset 

    bash preprocess.sh path/to/the/sgraph/folder

Then download the pre-processed RCNN features from

    https://www.dropbox.com/s/535so55t5cnhlxp/gqa_rcnn_feat.zip?dl=0

And put the folder right under the gqa folder

    code (root)
    |_ README.md
    |_ data
    |_   |_ gqa
    |_      |_ gqa_rcnn_feat
    |_      |_ fact_domains
    |_      |_ ... 
    |_ ...

Now you can run experiment with

    bash run_exp.sh