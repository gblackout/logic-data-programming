cd data_process

p="../${1}"
python gqa_process.py $p